package Controladores;

import Modelos.Categoria_Productros_1_mod;
import java.sql.SQLException;

public class Categoria_Productos_1_Con {
    
    //ingresar Datos a Caterogia
    public Boolean add_Categoria_Producto(String UserInfo, String CodigoCP, String NombreCP) throws SQLException{
        
        Boolean confirm = null;                
        Categoria_Productros_1_mod op = new Categoria_Productros_1_mod();
        
        confirm = op.add(UserInfo, CodigoCP, NombreCP);        
        System.out.println(confirm);        
        return confirm;
    }
    
    //testing
     public static void main(String[] args) throws SQLException {        
        Categoria_Productos_1_Con op2 = new Categoria_Productos_1_Con();
        op2.add_Categoria_Producto("davel", "008", "usuario");
     }
    
    
}
