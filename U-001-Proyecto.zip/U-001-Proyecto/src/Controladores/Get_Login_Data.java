package Controladores;

import Modelos.Check_Login_mod;
import java.sql.SQLException;

public class Get_Login_Data {
    
    //REGRESA FALSO O VERDADERO SI EL USUARIO EXISTE O NO 
    public Boolean Check_Login(String User, String Pass) throws SQLException{
        
        Check_Login_mod op = new Check_Login_mod();
        Boolean existe = op.Loggin(User, Pass);
                
        //System.out.println(existe);
        return existe;        
    }
    
    
    public void login(){
    
        
    }
    
    
    
            // MOTIVOS DE PRUEBAS.
    public static void main(String[] args) throws SQLException {
        
        Get_Login_Data op = new Get_Login_Data();
        op.Check_Login("davel", "12345");
    }
    
}
