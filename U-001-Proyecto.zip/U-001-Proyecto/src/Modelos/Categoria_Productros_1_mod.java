package Modelos;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

public class Categoria_Productros_1_mod extends Data_Base_Con {
    
    //INGRESAR DATOS TABLA 1 Y CONFIRMAR SI EXISTE EL CODIGO DEL PRODUCTO
    public Boolean add(String UserInfo, String CodigoCP, String NombreCP) throws SQLException {           
         
        con();
        String buscar = CodigoCP;
        Boolean confirmation = null;
                
        String sql2 = "SELECT * FROM tabla1_cat_producto WHERE codigoCP='CP"+buscar+"' ";
        st = conexion.createStatement();
        rs = st.executeQuery(sql2);
        
       if ( rs.next()){
                    confirmation = false; 
                    try {pst.close(); } catch (Exception e) { }
                    try {dis(); } catch (Exception e) { }      
       } else  {
           
           try {                 
                 String sql= "INSERT INTO tabla1_cat_producto (user, codigoCP, nombreCP) VALUES (?, ?, ?)";
                 pst = conexion.prepareStatement(sql);
                 pst.setString(1,UserInfo);
                 pst.setString(2,"CP"+CodigoCP);
                 pst.setString(3,NombreCP);

                 if (pst.executeUpdate() == 1) {
                     confirmation = true;
                 } else {
                     confirmation = false;
                 }
                 
               } finally {          
                   try {pst.close(); } catch (Exception e) { }
                   try {dis(); } catch (Exception e) { }             
               }                      
       }                            
       return   confirmation;
    }
    
    public ArrayList<Variables_datos> getCategoriaProductos() throws SQLException {
        
        ArrayList<Variables_datos> categoriaProductosList= new ArrayList<Variables_datos>();
        con();
        String query = "SELECT * FROM tabla1_cat_producto";        
        
        try {
            st = conexion.createStatement();
            rs = st.executeQuery(query);
            Variables_datos op;
            while(rs.next()){
                op = new Variables_datos(rs.getString("codigoCP"), rs.getString("nombreCP"));
                categoriaProductosList.add(op);                
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return categoriaProductosList;
    }
    
    public Boolean Delete(String CodigoCP) throws SQLException{
        Boolean confirm = false;
        con();        
        String sql = "DELETE FROM tabla1_cat_producto WHERE codigoCP='"+CodigoCP+"'";
        
        st = conexion.createStatement();
        
        if (st.executeUpdate(sql)==1){
            confirm = true;
        } 
        
        dis();
        return confirm;
    }
    
    public Boolean Update(String CodigoCP, String NombreCP) throws SQLException {
        Boolean confirm = false;
        con();
        String sql = "UPDATE tabla1_cat_producto SET nombreCP=? WHERE codigoCP='"+CodigoCP+"' ";        
        
        pst = conexion.prepareStatement(sql);
        pst.setString (1, NombreCP);              
                
        if (pst.executeUpdate()==1){
            confirm = true;
        } 
        pst.close();
        dis();
        return confirm;
    }
    
     public ArrayList<Variables_datos> findCategoriaProductos(String codigoCP) throws SQLException {
        
        ArrayList<Variables_datos> categoriaProductosList= new ArrayList<Variables_datos>();
        con();
        String query = "SELECT * FROM tabla1_cat_producto WHERE codigoCP ='CP"+codigoCP+"' ";        
        
        try {
            st = conexion.createStatement();
            rs = st.executeQuery(query);
            Variables_datos op;
            
            if (rs.next()){
                
                   op = new Variables_datos(rs.getString("codigoCP"), rs.getString("nombreCP"));
                   categoriaProductosList.add(op);                
               
            }                  
           
        }catch (Exception e){
            e.printStackTrace();
        }
        return categoriaProductosList;
    }
}
