
package Modelos;

import java.sql.SQLException;

public class Check_Login_mod extends Data_Base_Con {           
    
    //CHECKEAR IF USER EXIST
    public Boolean Loggin(String user, String pass) throws SQLException {
        
        Boolean accessing=null;
        
        con();
        String sql = "SELECT user, pass FROM users WHERE user='"+user+"' AND pass='"+pass+"' ";
        st = conexion.createStatement();
        rs = st.executeQuery(sql);
        
       if(rs.next()){
            accessing = true;  
        } else {
            accessing = false;
        }
        
        rs.close();
        st.close();
        dis();
        return accessing;
    }
    
    
}
