package Modelos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Data_Base_Con {
    
    public Connection conexion = null;    
    String host,user,db,pass = null;
    PreparedStatement pst = null;
    PreparedStatement pst2 = null;
    
    Statement st = null;    
    ResultSet rs = null;
    Statement st2 = null;    
    ResultSet rs2 = null;
    
    
    public Data_Base_Con ()
    {
        
        host = "localhost";
        this.db = "test2";
        this.user = "root";
        this.pass = "";   
                
        //this.host = "localhost:3306";
        //this.db = "xspacein_todo";
        //this.user = "xspacein_user";
        //this.pass = "Test2020";        
        
    }
    
    public void con() throws SQLException {
       try {
            Class.forName("com.mysql.jdbc.Driver");
            conexion =DriverManager.getConnection("jdbc:mysql://"+this.host+"/"+this.db,this.user,this.pass);                    
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }        
    }
    
    public void dis() throws SQLException{
        conexion.close();
        
    }
    
}
