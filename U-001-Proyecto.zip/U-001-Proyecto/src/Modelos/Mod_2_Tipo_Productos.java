
package Modelos;

import java.sql.SQLException;
import java.util.ArrayList;


public class Mod_2_Tipo_Productos extends Data_Base_Con {
        
    public Boolean add(String UserInfo, String CodigoCP, String NombreCP, String CodigoTP, String NombreTP) throws SQLException {           
         
        con();
        String buscar = CodigoTP;
        Boolean confirmation = null;
                
        String sql2 = "SELECT * FROM tabla2_tipo_producto WHERE codigoTP='TP"+buscar+"' ";
        st = conexion.createStatement();
        rs = st.executeQuery(sql2);
        
       if ( rs.next()){
                    confirmation = false; 
                    try {pst.close(); } catch (Exception e) { }
                    try {dis(); } catch (Exception e) { }      
       } else  {
           
           try {                 
                 String sql= "INSERT INTO tabla2_tipo_producto (user, codigoCP, nombreCP, codigoTP, nombreTP) VALUES (?, ?, ?, ?, ?)";
                 pst = conexion.prepareStatement(sql);
                 pst.setString(1,UserInfo);
                 pst.setString(2,CodigoCP);
                 pst.setString(3,NombreCP);
                 pst.setString(4,"TP"+CodigoTP);
                 pst.setString(5,NombreTP);

                 if (pst.executeUpdate() == 1) {
                     confirmation = true;
                 } else {
                     confirmation = false;
                 }
                 
               } finally {          
                   try {pst.close(); } catch (Exception e) { }
                   try {dis(); } catch (Exception e) { }             
               }                      
       }                            
       return   confirmation;
    }
    
    // este!!!!
    public ArrayList<Variables_datos> getCategoriaProductos() throws SQLException {
        
        ArrayList<Variables_datos> categoriaProductosList= new ArrayList<Variables_datos>();
        con();
        String query = "SELECT * FROM tabla2_tipo_producto";        
        
        try {
            st = conexion.createStatement();
            rs = st.executeQuery(query);
            Variables_datos op;
            while(rs.next()){
                op = new Variables_datos(rs.getString("codigoCP"), rs.getString("nombreCP"),rs.getString("codigoTP"), rs.getString("nombreTP"));
                categoriaProductosList.add(op);                
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return categoriaProductosList;
    }
    
     public Boolean Delete(String CodigoTP) throws SQLException{
        Boolean confirm = false;
        con();        
        String sql = "DELETE FROM tabla2_tipo_producto WHERE codigoTP='"+CodigoTP+"'";
        
        st = conexion.createStatement();
        
        if (st.executeUpdate(sql)==1){
            confirm = true;
        } 
        
        dis();
        return confirm;
    }
    
    public Boolean Update(String CodigoTP, String NombreTP) throws SQLException {
        Boolean confirm = false;
        con();
        String sql = "UPDATE tabla2_tipo_producto SET nombreTP=? WHERE codigoTP='"+CodigoTP+"' ";        
               
        
        pst = conexion.prepareStatement(sql);
        pst.setString (1, NombreTP);              
                              
        if (pst.executeUpdate()==1){
            confirm = true;
        } 
        pst.close();
        dis();
        return confirm;
    }
    
    public ArrayList<Variables_datos> findCategoriaProductos(String codigo) throws SQLException {
        
        ArrayList<Variables_datos> categoriaProductosList= new ArrayList<Variables_datos>();
        con();
        String query = "SELECT * FROM tabla2_tipo_producto WHERE codigoTP ='TP"+codigo+"' ";        
        
        try {
            st = conexion.createStatement();
            rs = st.executeQuery(query);
            Variables_datos op;
            
            if (rs.next()){                
                   op = new Variables_datos(rs.getString("codigoCP"), rs.getString("nombreCP"),rs.getString("codigoTP"), rs.getString("nombreTP"));
                   categoriaProductosList.add(op);                               
            }                  
           
        }catch (Exception e){
            e.printStackTrace();
        }
        return categoriaProductosList;
    }
}
