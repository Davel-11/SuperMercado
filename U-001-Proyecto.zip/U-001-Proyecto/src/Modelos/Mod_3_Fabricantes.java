
package Modelos;

import java.sql.SQLException;
import java.util.ArrayList;


public class Mod_3_Fabricantes extends Data_Base_Con {
    
    public Boolean add(String UserInfo, String Codigo, String Nombre) throws SQLException {           
         
        con();
        String buscar = Codigo;
        Boolean confirmation = null;
                
        String sql2 = "SELECT * FROM tabla3_fabricante WHERE codigoFab='FB"+buscar+"' ";
        st = conexion.createStatement();
        rs = st.executeQuery(sql2);
        
       if ( rs.next()){
                    confirmation = false; 
                    try {pst.close(); } catch (Exception e) { }
                    try {dis(); } catch (Exception e) { }      
       } else  {
           
           try {                 
                 String sql= "INSERT INTO tabla3_fabricante (user, codigoFab, nombreFab) VALUES (?, ?, ?)";
                 pst = conexion.prepareStatement(sql);
                 pst.setString(1,UserInfo);
                 pst.setString(2,"FB"+Codigo);
                 pst.setString(3,Nombre);

                 if (pst.executeUpdate() == 1) {
                     confirmation = true;
                 } else {
                     confirmation = false;
                 }
                 
               } finally {          
                   try {pst.close(); } catch (Exception e) { }
                   try {dis(); } catch (Exception e) { }             
               }                      
       }                            
       return   confirmation;
    }
    
    public ArrayList<Variables_Fabricantes> getCategoriaProductos() throws SQLException {
        
        ArrayList<Variables_Fabricantes> categoriaProductosList= new ArrayList<Variables_Fabricantes>();
        con();
        String query = "SELECT * FROM tabla3_fabricante";        
        
        try {
            st = conexion.createStatement();
            rs = st.executeQuery(query);
            Variables_Fabricantes op;
            while(rs.next()){
                op = new Variables_Fabricantes(rs.getString("codigoFab"), rs.getString("nombreFab"));
                categoriaProductosList.add(op);                
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return categoriaProductosList;
    }
    
    public Boolean Delete(String Codigo) throws SQLException{
        Boolean confirm = false;
        con();        
        String sql = "DELETE FROM tabla3_fabricante WHERE codigoFab='"+Codigo+"'";
        
        st = conexion.createStatement();
        
        if (st.executeUpdate(sql)==1){
            confirm = true;
        } 
        
        dis();
        return confirm;
    }
    
    public Boolean Update(String Codigo, String Nombre) throws SQLException {
        Boolean confirm = false;
        con();
        String sql = "UPDATE tabla3_fabricante SET nombreFab=? WHERE codigoFab='"+Codigo+"' ";        
              
        
        pst = conexion.prepareStatement(sql);
        pst.setString (1, Nombre); 
                
                
        if (pst.executeUpdate()==1){
            confirm = true;
        } 
        pst.close();
        dis();
        return confirm;
    }
    
    public ArrayList<Variables_Fabricantes> findCategoriaProductos(String codigo) throws SQLException {
        
        ArrayList<Variables_Fabricantes> findfabricante = new ArrayList<Variables_Fabricantes>();
        con();
        String query = "SELECT * FROM tabla3_fabricante WHERE codigoFab ='FB"+codigo+"' ";        
        
        try {
            st = conexion.createStatement();
            rs = st.executeQuery(query);
            Variables_Fabricantes op;
            
            if (rs.next()){                
                   op = new Variables_Fabricantes(rs.getString("codigoFab"), rs.getString("nombreFab"));
                   findfabricante.add(op);                
               
            }                  
           
        }catch (Exception e){
            e.printStackTrace();
        }
        return findfabricante;
    }
    
     
}
