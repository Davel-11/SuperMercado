
package Modelos;

import java.sql.SQLException;
import java.util.ArrayList;

public class Mod_4_Productos extends Data_Base_Con {
    
    public Boolean add(String UserInfo, String CodigoFab, String nombreFab, String CodigoTP, String NombreTP, String CodigoProducto, String NombreProducto, Double PrecioVenta, Double PrecioCompra, int NoExistencias) throws SQLException {           
         
        con();
        String buscar = CodigoProducto;
        Boolean confirmation = null;
                
        String sql2 = "SELECT * FROM tabla4_productos WHERE codigo_producto='"+buscar+"' ";
        st = conexion.createStatement();
        rs = st.executeQuery(sql2);
        
       if ( rs.next()){
                    confirmation = false; 
                    try {pst.close(); } catch (Exception e) { }
                    try {dis(); } catch (Exception e) { }      
       } else  {
           
           try {                 
                 String sql= "INSERT INTO tabla4_productos (user, codigoFab, nombreFab, codigoTP, nombreTP, codigo_producto, nombre_producto, 	precio_venta, precio_compra, no_existencias) VALUES (?, ?, ?, ?, ?,?, ?, ?, ?, ?)";
                 pst = conexion.prepareStatement(sql);
                 pst.setString(1,UserInfo);
                 pst.setString(2,CodigoFab);
                 pst.setString(3,nombreFab);
                 pst.setString(4,CodigoTP);
                 pst.setString(5,NombreTP);
                 pst.setString(6,CodigoProducto);
                 pst.setString(7,NombreProducto);
                 pst.setDouble(8,PrecioVenta);
                 pst.setDouble(9,PrecioCompra);
                 pst.setInt(10,NoExistencias);

                 if (pst.executeUpdate() == 1) {
                     confirmation = true;
                 } else {
                     confirmation = false;
                 }
                 
               } finally {          
                   try {pst.close(); } catch (Exception e) { }
                   try {dis(); } catch (Exception e) { }             
               }                      
       }                            
       return   confirmation;
    }
    
    public ArrayList<Variables_datos_2_Fab> getCategoriaProductos() throws SQLException {
        
        ArrayList<Variables_datos_2_Fab> categoriaProductosList= new ArrayList<Variables_datos_2_Fab>();
        con();
        String query = "SELECT * FROM tabla4_productos";        
        
        try {
            st = conexion.createStatement();
            rs = st.executeQuery(query);
            Variables_datos_2_Fab op;
            while(rs.next()){
                op = new Variables_datos_2_Fab(rs.getString("codigoFab"), rs.getString("nombreFab"), rs.getString("codigoTP"), rs.getString("nombreTP"),rs.getString("codigo_producto"), rs.getString("nombre_producto"), rs.getDouble("precio_venta"), rs.getDouble("precio_compra"),rs.getInt("no_existencias"));
                categoriaProductosList.add(op);                
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return categoriaProductosList;
    }
    
    public Boolean Update(String UserInfo, String CodigoFab, String NombreFab, String CodigoTP, String NombreTP, String CodigoProducto, String NombreProducto, Double PrecioVenta, Double PrecioCompra, int NoExistencias) throws SQLException {
        Boolean confirm = false;
        con();
        String sql = "UPDATE tabla4_productos SET user=?, codigoFab=?, nombreFab=?, codigoTP=?, nombreTP=?, nombre_producto=?, precio_venta=?, precio_compra=?, no_existencias=? WHERE codigo_producto='"+CodigoProducto+"' ";        
        
        pst = conexion.prepareStatement(sql);
                 pst.setString(1,UserInfo);
                 
                 pst.setString(2,CodigoFab);
                 pst.setString(3,NombreFab);
                 pst.setString(4,CodigoTP);
                 pst.setString(5,NombreTP);
                 
                 
                 pst.setString(6,NombreProducto);
                 pst.setDouble(7,PrecioVenta);
                 pst.setDouble(8,PrecioCompra);
                 pst.setInt(9,NoExistencias);             
                
        if (pst.executeUpdate()==1){
            confirm = true;
        } 
        pst.close();
        dis();
        return confirm;
    }
    
    public Boolean Delete(String Codigo) throws SQLException{
        
        Boolean confirm = false;
        con();        
        String sql = "DELETE FROM tabla4_productos WHERE codigo_producto='"+Codigo+"'";
        
        st = conexion.createStatement();
        
        if (st.executeUpdate(sql)==1){
            confirm = true;
        } 
        
        dis();
        return confirm;
    }
    
    public ArrayList<Variables_datos_2_Fab> findCodigo(String codigo) throws SQLException {
        
        ArrayList<Variables_datos_2_Fab> lista= new ArrayList<Variables_datos_2_Fab>();
        con();
        String query = "SELECT * FROM tabla4_productos WHERE codigo_producto ='"+codigo+"' ";        
        
        try {
            st = conexion.createStatement();
            rs = st.executeQuery(query);
            Variables_datos_2_Fab op;
            
            if (rs.next()){                
                   op = new Variables_datos_2_Fab(rs.getString("codigo_producto"), rs.getString("nombre_producto"));
                   lista.add(op);                               
            }                  
           
        }catch (Exception e){
            e.printStackTrace();
        }
        return lista;
    }
}
