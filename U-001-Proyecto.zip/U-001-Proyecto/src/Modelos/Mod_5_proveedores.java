
package Modelos;

import java.sql.SQLException;
import java.util.ArrayList;


public class Mod_5_proveedores extends Data_Base_Con {
    
public Boolean add(String UserInfo, String NitProveedor, String Nom_proveedor, String Direccion, String Telefono, String Nombre_Contacto) throws SQLException {           
         
        con();
        String buscar = NitProveedor;
        Boolean confirmation = null;
                
        String sql2 = "SELECT * FROM tabla5_Proveedor WHERE nit_proveedor='"+buscar+"' ";
        st = conexion.createStatement();
        rs = st.executeQuery(sql2);
        
       if ( rs.next()){
                    confirmation = false; 
                    try {pst.close(); } catch (Exception e) { }
                    try {dis(); } catch (Exception e) { }      
       } else  {
           
           try {                 
                 String sql= "INSERT INTO tabla5_Proveedor (user, nit_proveedor, nom_proveedor, direccion, telefono, nombre_contacto) VALUES (?, ?, ?, ?, ?, ?)";
                 pst = conexion.prepareStatement(sql);
                 pst.setString(1,UserInfo);
                 pst.setString(2,NitProveedor);
                 pst.setString(3,Nom_proveedor);
                 pst.setString(4,Direccion);
                 pst.setString(5,Telefono);
                 pst.setString(6,Nombre_Contacto);
                                  

                 if (pst.executeUpdate() == 1) {
                     confirmation = true;
                 } else {
                     confirmation = false;
                 }
                 
               } finally {          
                   try {pst.close(); } catch (Exception e) { }
                   try {dis(); } catch (Exception e) { }             
               }                      
       }                            
       return   confirmation;
    }    

public ArrayList<Variables_Proveedores> getCategoriaProductos() throws SQLException {
        
        ArrayList<Variables_Proveedores> Listado = new ArrayList<Variables_Proveedores>();
        con();
        String query = "SELECT * FROM tabla5_Proveedor";        
        
        try {
            st = conexion.createStatement();
            rs = st.executeQuery(query);
            Variables_Proveedores op;
            while(rs.next()){
                op = new Variables_Proveedores(rs.getString("nit_proveedor"), rs.getString("nom_proveedor"), rs.getString("direccion"), rs.getString("telefono"),rs.getString("nombre_contacto"));
                Listado.add(op);                
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return Listado;
    }

public Boolean Update(String UserInfo, String NitProveedor, String Nom_proveedor, String Direccion, String Telefono, String Nombre_Contacto) throws SQLException {
        Boolean confirm = false;
        con();
        String sql = "UPDATE tabla5_Proveedor SET user=?, nom_proveedor=?, direccion=?, telefono=?, nombre_contacto=? WHERE nit_proveedor='"+NitProveedor+"' ";        
        
        pst = conexion.prepareStatement(sql);
                 pst.setString(1,UserInfo);
                 pst.setString(2,Nom_proveedor);
                 pst.setString(3,Direccion);
                 pst.setString(4,Telefono);
                 pst.setString(5,Nombre_Contacto);
                                        
                 
                
        if (pst.executeUpdate()==1){
            confirm = true;
        } 
        pst.close();
        dis();
        return confirm;
    }

public Boolean Delete(String Codigo) throws SQLException{
        Boolean confirm = false;
        con();        
        String sql = "DELETE FROM tabla5_Proveedor WHERE nit_proveedor='"+Codigo+"'";
        
        st = conexion.createStatement();
        
        if (st.executeUpdate(sql)==1){
            confirm = true;
        } 
        
        dis();
        return confirm;
    }

public ArrayList<Variables_Proveedores> findProveedor(String codigo) throws SQLException {
        
        ArrayList<Variables_Proveedores> lista = new ArrayList<Variables_Proveedores>();
        con();
        String query = "SELECT * FROM tabla5_proveedor WHERE nit_proveedor ='"+codigo+"' ";        
        
        try {
            st = conexion.createStatement();
            rs = st.executeQuery(query);
            Variables_Proveedores op;
            
            if (rs.next()){                
                   op = new Variables_Proveedores(rs.getString("nit_proveedor"), rs.getString("nom_proveedor"));
                   lista.add(op);                               
            }                  
           
        }catch (Exception e){
            e.printStackTrace();
        }
        return lista;
    }
}
