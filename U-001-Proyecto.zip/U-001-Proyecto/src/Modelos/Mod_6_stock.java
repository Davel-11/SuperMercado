
package Modelos;

import java.sql.SQLException;
import java.util.ArrayList;


public class Mod_6_stock extends Data_Base_Con {
    
public Boolean add(String UserInfo, String CodigoCompra, String FechaCompra, String CodigoProducto, Double PrecioCompra, int Acomprados, String CodigoProveedor) throws SQLException {           
         
        con();
        String buscar = CodigoCompra;
        Boolean confirmation = null;
                
        String sql2 = "SELECT * FROM tabla6_stock WHERE cod_compra='"+buscar+"' ";
        st = conexion.createStatement();
        rs = st.executeQuery(sql2);
        
       if ( rs.next()){
                    confirmation = false; 
                    try {pst.close(); } catch (Exception e) { }
                    try {dis(); } catch (Exception e) { }      
       } else  {
           
           try {                 
                 String sql= "INSERT INTO tabla6_stock (user, cod_compra, fecha_compra, codigo_producto, precio_compra, no_articulos_comprados, codigo_proveedor) VALUES (?, ?, ?, ?, ?, ?, ?)";
                 
                 pst = conexion.prepareStatement(sql);                                
                 
                 pst.setString(1,UserInfo);         
                 pst.setString(2,CodigoCompra);
                 pst.setString(3,FechaCompra);
                                  
                 pst.setString(4,CodigoProducto);
                 pst.setDouble(5,PrecioCompra);
                 pst.setInt(6,Acomprados);
                 pst.setString(7,CodigoProveedor);                                                   

                 if (pst.executeUpdate() == 1) {
                     confirmation = true;
                 } else {
                     confirmation = false;
                 }
                 
               } finally {          
                   try {pst.close(); } catch (Exception e) { }
                   try {dis(); } catch (Exception e) { }             
               }                      
       }                            
       return   confirmation;
    }    

//done
public ArrayList<Variables_stock> getCategoriaProductos() throws SQLException {
        
        ArrayList<Variables_stock> Listado = new ArrayList<Variables_stock>();
        con();
        String query = "SELECT * FROM tabla6_stock";        
        
        try {
            st = conexion.createStatement();
            rs = st.executeQuery(query);
            Variables_stock op;
            while(rs.next()){
                op = new Variables_stock(rs.getString("codigo_producto"), rs.getString("precio_compra"), rs.getString("no_articulos_comprados"), rs.getString("codigo_proveedor"),rs.getString("fecha_compra"),rs.getString("cod_compra"));
                Listado.add(op);                
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return Listado;
    }

//done
public Boolean Update(String UserInfo, String CodigoCompra, String FechaCompra, String CodigoProducto, Double PrecioCompra, int Acomprados, String CodigoProveedor) throws SQLException {
        
    Boolean confirm = false;
        con();
        String sql = "UPDATE tabla6_stock SET user=?, cod_compra=?, fecha_compra=?, codigo_producto=?, precio_compra=?, no_articulos_comprados=?, codigo_proveedor=? WHERE cod_compra='"+CodigoCompra+"' ";        
        
        pst = conexion.prepareStatement(sql);
                 pst.setString(1,UserInfo);         
                 pst.setString(2,CodigoCompra);
                 pst.setString(3,FechaCompra);
                                  
                 pst.setString(4,CodigoProducto);
                 pst.setDouble(5,PrecioCompra);
                 pst.setInt(6,Acomprados);
                 pst.setString(7,CodigoProveedor);   
                                        
                 
                
        if (pst.executeUpdate()==1){
            confirm = true;
        } 
        pst.close();
        dis();
        return confirm;
    }

public Boolean Delete(String Codigo) throws SQLException{
        Boolean confirm = false;
        con();        
        String sql = "DELETE FROM tabla6_stock WHERE cod_compra='"+Codigo+"'";
        
        st = conexion.createStatement();
        
        if (st.executeUpdate(sql)==1){
            confirm = true;
        } 
        
        dis();
        return confirm;
    }



}
