
package Modelos;

import java.sql.SQLException;
import java.util.ArrayList;


public class Mod_7_Clientes extends Data_Base_Con {
        
    //done
    public Boolean add(String User, String nitCliente, String nomCliente, String apeCliente, String telCliente, String dirCliente) throws SQLException {           
         
        con();
        String buscar = nitCliente;
        Boolean confirmation = null;
                
        String sql2 = "SELECT * FROM tabla7_clientes WHERE nitCliente='"+nitCliente+"' ";
        st = conexion.createStatement();
        rs = st.executeQuery(sql2);
        
       if ( rs.next()){
                    confirmation = false; 
                    try {pst.close(); } catch (Exception e) { }
                    try {dis(); } catch (Exception e) { }      
       } else  {
           
           try {                 
                 String sql= "INSERT INTO tabla7_clientes (user, nitCliente, nomCliente, apeCliente, telCliente, dirCliente) VALUES (?, ?, ?, ?, ?, ?)";
                 pst = conexion.prepareStatement(sql);
                 pst.setString(1,User);
                 pst.setString(2,nitCliente);
                 pst.setString(3,nomCliente);
                 pst.setString(4,apeCliente);
                 pst.setString(5,telCliente);
                 pst.setString(6,dirCliente);

                 if (pst.executeUpdate() == 1) {
                     confirmation = true;
                 } else {
                     confirmation = false;
                 }
                 
               } finally {          
                   try {pst.close(); } catch (Exception e) { }
                   try {dis(); } catch (Exception e) { }             
               }                      
       }                            
       return   confirmation;
    }
    
    //done
    public ArrayList<Variables_Clientes> getClientes() throws SQLException {
        
        ArrayList<Variables_Clientes> lista = new ArrayList<Variables_Clientes>();
        con();
        String query = "SELECT * FROM tabla7_clientes";        
        
        try {
            st = conexion.createStatement();
            rs = st.executeQuery(query);
            Variables_Clientes op;
            while(rs.next()){
                op = new Variables_Clientes(rs.getString("nitCliente"), rs.getString("nomCliente"),rs.getString("apeCliente"), rs.getString("telCliente"), rs.getString("dirCliente"));
                lista.add(op);                
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return lista;
    }
    
    //done
    public Boolean Delete(String Codigo) throws SQLException{
        Boolean confirm = false;
        con();        
        String sql = "DELETE FROM tabla7_clientes WHERE nitCliente='"+Codigo+"'";
        
        st = conexion.createStatement();
        
        if (st.executeUpdate(sql)==1){
            confirm = true;
        } 
        
        dis();
        return confirm;
    }
    
    //done
    public Boolean Update(String User, String nitCliente, String nomCliente, String apeCliente, String telCliente, String dirCliente) throws SQLException {
        Boolean confirm = false;
        con();
        String sql = "UPDATE tabla7_clientes SET user=?, nomCliente=?, apeCliente=?, telCliente=?, dirCliente=? WHERE nitCliente='"+nitCliente+"' ";        
               
        
        pst = conexion.prepareStatement(sql);
        pst.setString (1, User);              
        pst.setString (2, nomCliente); 
        pst.setString (3, apeCliente); 
        pst.setString (4, telCliente); 
        pst.setString (5, dirCliente); 
        
                              
        if (pst.executeUpdate()==1){
            confirm = true;
        } 
        pst.close();
        dis();
        return confirm;
    }
    
    public ArrayList<Variables_Clientes> findCliente(String codigo) throws SQLException {
        
        ArrayList<Variables_Clientes> categoriaProductosList= new ArrayList<>();
        con();
        String query = "SELECT * FROM tabla7_clientes WHERE nitCliente ='"+codigo+"' ";        
        
        try {
            st = conexion.createStatement();
            rs = st.executeQuery(query);
            Variables_Clientes op;
            
            if (rs.next()){                
                   op = new Variables_Clientes(rs.getString("nitCliente"), rs.getString("nomCliente"),rs.getString("apeCliente"), rs.getString("telCliente"), rs.getString("dirCliente"));
                   categoriaProductosList.add(op);                               
            }                  
           
        }catch (Exception e){
            e.printStackTrace();
        }
        return categoriaProductosList;
    }
}
