
package Modelos;

import java.sql.SQLException;
import java.util.ArrayList;


public class Mod_8_venta extends Data_Base_Con {
        
    //done
    public Boolean add(String User, String nitCliente, String nomCliente, String apeCliente, String telCliente, String dirCliente) throws SQLException {           
         
        con();
        String buscar = nitCliente;
        Boolean confirmation = null;
                
        String sql2 = "SELECT * FROM tabla7_clientes WHERE nitCliente='"+nitCliente+"' ";
        st = conexion.createStatement();
        rs = st.executeQuery(sql2);
        
       if ( rs.next()){
                    confirmation = false; 
                    try {pst.close(); } catch (Exception e) { }
                    try {dis(); } catch (Exception e) { }      
       } else  {
           
           try {                 
                 String sql= "INSERT INTO tabla7_clientes (user, nitCliente, nomCliente, apeCliente, telCliente, dirCliente) VALUES (?, ?, ?, ?, ?, ?)";
                 pst = conexion.prepareStatement(sql);
                 pst.setString(1,User);
                 pst.setString(2,nitCliente);
                 pst.setString(3,nomCliente);
                 pst.setString(4,apeCliente);
                 pst.setString(5,telCliente);
                 pst.setString(6,dirCliente);

                 if (pst.executeUpdate() == 1) {
                     confirmation = true;
                 } else {
                     confirmation = false;
                 }
                 
               } finally {          
                   try {pst.close(); } catch (Exception e) { }
                   try {dis(); } catch (Exception e) { }             
               }                      
       }                            
       return   confirmation;
    }
    
    //done
    public ArrayList<Variables_Venta> getVenta(String codigo) throws SQLException {
        
        ArrayList<Variables_Venta> lista = new ArrayList<Variables_Venta>();
        con();
        String query = "SELECT * FROM tabla4_productos WHERE codigo_producto='"+codigo+"' ";        
        
        try {
            st = conexion.createStatement();
            rs = st.executeQuery(query);
            Variables_Venta op;
            
            if ( rs.next()) {
                //while(rs.next()){
                    op = new Variables_Venta(rs.getString("codigo_producto"), rs.getString("nombre_producto"),rs.getDouble("precio_venta"),rs.getInt("no_existencias"));
                    lista.add(op);                
                //}
            } 
        }catch (Exception e){
            e.printStackTrace();
        }
        return lista;
    }
    
    /*
    public Boolean Delete(String Codigo) throws SQLException{
        Boolean confirm = false;
        con();        
        String sql = "DELETE FROM tabla7_clientes WHERE nitCliente='"+Codigo+"'";
        
        st = conexion.createStatement();
        
        if (st.executeUpdate(sql)==1){
            confirm = true;
        } 
        
        dis();
        return confirm;
    }
    
    */
    
    
    public Boolean Update(String codigo, int NuevaExist) throws SQLException {
        Boolean confirm = false;
        con();
        String sql = "UPDATE tabla4_productos SET no_existencias=? WHERE codigo_producto='"+codigo+"' ";        
               
        
        pst = conexion.prepareStatement(sql);
        pst.setInt(1, NuevaExist);              
                
                              
        if (pst.executeUpdate()==1){
            confirm = true;
        } 
        pst.close();
        dis();
        return confirm;
    }
    
 
    public ArrayList<Variables_Clientes> findCliente(String codigo) throws SQLException {
        
        ArrayList<Variables_Clientes> categoriaProductosList= new ArrayList<>();
        con();
        String query = "SELECT * FROM tabla7_clientes WHERE nitCliente ='"+codigo+"' ";        
        
        try {
            st = conexion.createStatement();
            rs = st.executeQuery(query);
            Variables_Clientes op;
            
            if (rs.next()){                
                   op = new Variables_Clientes(rs.getString("nitCliente"), rs.getString("nomCliente"),rs.getString("apeCliente"), rs.getString("telCliente"), rs.getString("dirCliente"));
                   categoriaProductosList.add(op);                               
            }                  
           
        }catch (Exception e){
            e.printStackTrace();
        }
        return categoriaProductosList;
    }
    
   

}
