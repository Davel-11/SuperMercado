package Modelos;

public class Variables_Clientes {
    
    private String nitCliente;
    private String nomCliente;    
    private String apeCliente;
    private String telCliente;
    private String dirCliente;
           
  
     public Variables_Clientes(String a, String b, String c, String d, String e){
        this.nitCliente = a;
        this.nomCliente = b;
        this.apeCliente = c;
        this.telCliente = d;
        this.dirCliente = e;
    }

    /**
     * @return the nitCliente
     */
    public String getNitCliente() {
        return nitCliente;
    }

    /**
     * @param nitCliente the nitCliente to set
     */
    public void setNitCliente(String nitCliente) {
        this.nitCliente = nitCliente;
    }

    /**
     * @return the nomCliente
     */
    public String getNomCliente() {
        return nomCliente;
    }

    /**
     * @param nomCliente the nomCliente to set
     */
    public void setNomCliente(String nomCliente) {
        this.nomCliente = nomCliente;
    }

    /**
     * @return the apeCliente
     */
    public String getApeCliente() {
        return apeCliente;
    }

    /**
     * @param apeCliente the apeCliente to set
     */
    public void setApeCliente(String apeCliente) {
        this.apeCliente = apeCliente;
    }

    /**
     * @return the telCliente
     */
    public String getTelCliente() {
        return telCliente;
    }

    /**
     * @param telCliente the telCliente to set
     */
    public void setTelCliente(String telCliente) {
        this.telCliente = telCliente;
    }

    /**
     * @return the dirCliente
     */
    public String getDirCliente() {
        return dirCliente;
    }

    /**
     * @param dirCliente the dirCliente to set
     */
    public void setDirCliente(String dirCliente) {
        this.dirCliente = dirCliente;
    }
        
  
    
    
}
