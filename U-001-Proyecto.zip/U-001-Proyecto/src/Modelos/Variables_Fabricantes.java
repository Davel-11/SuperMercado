
package Modelos;

public class Variables_Fabricantes {
    
    private String codigoFab;
    private String nombreFab;
    
     
    
    
    public Variables_Fabricantes(String Codigo, String Nombre){
        this.codigoFab = Codigo;
        this.nombreFab = Nombre;
        
        
    }

    /**
     * @return the codigoFab
     */
    public String getCodigoFab() {
        return codigoFab;
    }

    /**
     * @param codigoFab the codigoFab to set
     */
    public void setCodigoFab(String codigoFab) {
        this.codigoFab = codigoFab;
    }

    /**
     * @return the nombreFab
     */
    public String getNombreFab() {
        return nombreFab;
    }

    /**
     * @param nombreFab the nombreFab to set
     */
    public void setNombreFab(String nombreFab) {
        this.nombreFab = nombreFab;
    }
 

}