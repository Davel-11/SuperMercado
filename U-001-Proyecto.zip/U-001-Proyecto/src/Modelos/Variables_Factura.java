package Modelos;

public class Variables_Factura {
    
    private String nofactura;
    private String fecha;    
    private String tienda;    
    private String[][] productos;   
               
  
     public Variables_Factura(String a, String b, String c){
        this.nofactura = a;
        this.fecha = b;
        this.tienda = c;
        
    }

    /**
     * @return the nofactura
     */
    public String getNofactura() {
        return nofactura;
    }

    /**
     * @param nofactura the nofactura to set
     */
    public void setNofactura(String nofactura) {
        this.nofactura = nofactura;
    }

    /**
     * @return the fecha
     */
    public String getFecha() {
        return fecha;
    }

    /**
     * @param fecha the fecha to set
     */
    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    /**
     * @return the tienda
     */
    public String getTienda() {
        return tienda;
    }

    /**
     * @param tienda the tienda to set
     */
    public void setTienda(String tienda) {
        this.tienda = tienda;
    }

    /**
     * @return the productos
     */
    public String[][] getProductos() {
        return productos;
    }

    /**
     * @param productos the productos to set
     */
    public void setProductos(String[][] productos) {
        this.productos = productos;
    }

    
  
}
