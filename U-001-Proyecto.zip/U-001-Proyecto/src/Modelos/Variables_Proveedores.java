
package Modelos;


public class Variables_Proveedores {
    
    private String nitProveedor;
    private String nomProveedor;
    private String direccion;
    private String telefono;
    private String nombre_Contacto;
    
    public Variables_Proveedores(String a, String b, String c, String d, String e){
        this.nitProveedor = a;
        this.nomProveedor = b;
        this.direccion = c;
        this.telefono = d;
        this.nombre_Contacto = e;
    }
    
    public Variables_Proveedores(String a, String b){
        this.nitProveedor = a;
        this.nomProveedor = b;
        
    }

    /**
     * @return the nitProveedor
     */
    public String getNitProveedor() {
        return nitProveedor;
    }

    /**
     * @param nitProveedor the nitProveedor to set
     */
    public void setNitProveedor(String nitProveedor) {
        this.nitProveedor = nitProveedor;
    }

    /**
     * @return the nomProveedor
     */
    public String getNomProveedor() {
        return nomProveedor;
    }

    /**
     * @param nomProveedor the nomProveedor to set
     */
    public void setNomProveedor(String nomProveedor) {
        this.nomProveedor = nomProveedor;
    }

    /**
     * @return the direccion
     */
    public String getDireccion() {
        return direccion;
    }

    /**
     * @param direccion the direccion to set
     */
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    /**
     * @return the telefono
     */
    public String getTelefono() {
        return telefono;
    }

    /**
     * @param telefono the telefono to set
     */
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    /**
     * @return the nombre_Contacto
     */
    public String getNombre_Contacto() {
        return nombre_Contacto;
    }

    /**
     * @param nombre_Contacto the nombre_Contacto to set
     */
    public void setNombre_Contacto(String nombre_Contacto) {
        this.nombre_Contacto = nombre_Contacto;
    }
    
    
    
}
