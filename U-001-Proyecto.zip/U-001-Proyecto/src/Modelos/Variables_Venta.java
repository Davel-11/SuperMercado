package Modelos;

public class Variables_Venta {
    
    private String codigo;
    private String nombre;    
    private double precio;
    private int noExistencias;
               
  
     public Variables_Venta(String a, String b, double c, int d ){
        this.codigo = a;
        this.nombre = b;
        this.precio = c;
        this.noExistencias = d;
    }

    /**
     * @return the codigo
     */
    public String getCodigo() {
        return codigo;
    }

    /**
     * @param codigo the codigo to set
     */
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the precio
     */
    public double getPrecio() {
        return precio;
    }

    /**
     * @param precio the precio to set
     */
    public void setPrecio(double precio) {
        this.precio = precio;
    }

    /**
     * @return the noExistencias
     */
    public int getNoExistencias() {
        return noExistencias;
    }

    /**
     * @param noExistencias the noExistencias to set
     */
    public void setNoExistencias(int noExistencias) {
        this.noExistencias = noExistencias;
    }

    
}
