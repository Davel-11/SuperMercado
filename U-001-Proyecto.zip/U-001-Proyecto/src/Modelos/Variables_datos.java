package Modelos;

public class Variables_datos {
    
    private String codigoCP;
    private String nombreCP;
    
    private String codigoTP;
    private String nombreTP;
           
    public Variables_datos(String CodigoCP, String NombreCP){
        this.codigoCP = CodigoCP;
        this.nombreCP = NombreCP;
    }
    
     public Variables_datos(String CodigoCP, String NombreCP, String CodigoTP, String NombreTP){
        this.codigoCP = CodigoCP;
        this.nombreCP = NombreCP;
        this.codigoTP = CodigoTP;
        this.nombreTP = NombreTP;
    }
        
    public String getCodigoCP() {
        return codigoCP;
    }   
    public void setCodigoCP(String codigoCP) {
        this.codigoCP = codigoCP;
    }
   
    public String getNombreCP() {
        return nombreCP;
    }
    public void setNombreCP(String nombreCP) {
        this.nombreCP = nombreCP;
    }

    
    public String getCodigoTP() {
        return codigoTP;
    }    
    public void setCodigoTP(String codigoTP) {
        this.codigoTP = codigoTP;
    }

    public String getNombreTP() {
        return nombreTP;
    }    
    public void setNombreTP(String nombreTP) {
        this.nombreTP = nombreTP;
    }
    
    
    
}
