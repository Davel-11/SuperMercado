
package Modelos;

public class Variables_datos_2_Fab {
    
    private String codigoFab;
    private String nombreFab;
    
    private String codigoTP;
    private String nombreTP;
    
    private String codigo_producto;
    private String nombre_producto;
    
    private Double precio_venta;
    private Double precio_compra;
    
    private int no_existencias;
    
    
    
    
    public Variables_datos_2_Fab(String Codigo, String Nombre){
        this.codigo_producto = Codigo;
        this.nombre_producto = Nombre;
    }
    
    public Variables_datos_2_Fab(String CodigoFab, String nombreFab, String CodigoTP, String NombreTP, String CodigoProducto, String NombreProducto, Double PrecioVenta, Double PrecioCompra, int NoExistencias){
        this.codigoFab = CodigoFab;
        this.nombreFab = nombreFab;
        
        this.codigoTP = CodigoTP;
        this.nombreTP = NombreTP;
        
        this.codigo_producto = CodigoProducto;
        this.nombre_producto = NombreProducto;
        
        this.precio_venta = PrecioVenta;
        this.precio_compra = PrecioCompra;
        
        this.no_existencias = NoExistencias;
        
    }

    /**
     * @return the codigoFab
     */
    public String getCodigoFab() {
        return codigoFab;
    }

    /**
     * @param codigoFab the codigoFab to set
     */
    public void setCodigoFab(String codigoFab) {
        this.codigoFab = codigoFab;
    }

    /**
     * @return the nombreFab
     */
    public String getNombreFab() {
        return nombreFab;
    }

    /**
     * @param nombreFab the nombreFab to set
     */
    public void setNombreFab(String nombreFab) {
        this.nombreFab = nombreFab;
    }

    /**
     * @return the codigoTP
     */
    public String getCodigoTP() {
        return codigoTP;
    }

    /**
     * @param codigoTP the codigoTP to set
     */
    public void setCodigoTP(String codigoTP) {
        this.codigoTP = codigoTP;
    }

    /**
     * @return the nombreTP
     */
    public String getNombreTP() {
        return nombreTP;
    }

    /**
     * @param nombreTP the nombreTP to set
     */
    public void setNombreTP(String nombreTP) {
        this.nombreTP = nombreTP;
    }

    /**
     * @return the codigo_producto
     */
    public String getCodigo_producto() {
        return codigo_producto;
    }

    /**
     * @param codigo_producto the codigo_producto to set
     */
    public void setCodigo_producto(String codigo_producto) {
        this.codigo_producto = codigo_producto;
    }

    /**
     * @return the nombre_producto
     */
    public String getNombre_producto() {
        return nombre_producto;
    }

    /**
     * @param nombre_producto the nombre_producto to set
     */
    public void setNombre_producto(String nombre_producto) {
        this.nombre_producto = nombre_producto;
    }

    /**
     * @return the precio_venta
     */
    public Double getPrecio_venta() {
        return precio_venta;
    }

    /**
     * @param precio_venta the precio_venta to set
     */
    public void setPrecio_venta(Double precio_venta) {
        this.precio_venta = precio_venta;
    }

    /**
     * @return the precio_compra
     */
    public Double getPrecio_compra() {
        return precio_compra;
    }

    /**
     * @param precio_compra the precio_compra to set
     */
    public void setPrecio_compra(Double precio_compra) {
        this.precio_compra = precio_compra;
    }

    /**
     * @return the no_existencias
     */
    public int getNo_existencias() {
        return no_existencias;
    }

    /**
     * @param no_existencias the no_existencias to set
     */
    public void setNo_existencias(int no_existencias) {
        this.no_existencias = no_existencias;
    }
    
    
    
}
