
package Modelos;


public class Variables_stock {
    
    private String codigoProducto;
    private String precio_compra;
    private String no_articulos_comprados;
    private String codigo_proveedor;
    private String fecha_compra;
    private String cod_compra;
    
    public Variables_stock(String a, String b, String c, String d, String e, String f){
        this.codigoProducto = a;
        this.precio_compra = b;
        this.no_articulos_comprados = c;
        this.codigo_proveedor = d;
        this.fecha_compra = e;
        this.cod_compra = f;
        
    }

    /**
     * @return the precio_compra
     */
    public String getPrecio_compra() {
        return precio_compra;
    }

    /**
     * @param precio_compra the precio_compra to set
     */
    public void setPrecio_compra(String precio_compra) {
        this.precio_compra = precio_compra;
    }

    /**
     * @return the no_articulos_comprados
     */
    public String getNo_articulos_comprados() {
        return no_articulos_comprados;
    }

    /**
     * @param no_articulos_comprados the no_articulos_comprados to set
     */
    public void setNo_articulos_comprados(String no_articulos_comprados) {
        this.no_articulos_comprados = no_articulos_comprados;
    }

    /**
     * @return the codigo_proveedor
     */
    public String getCodigo_proveedor() {
        return codigo_proveedor;
    }

    /**
     * @param codigo_proveedor the codigo_proveedor to set
     */
    public void setCodigo_proveedor(String codigo_proveedor) {
        this.codigo_proveedor = codigo_proveedor;
    }

    /**
     * @return the fecha_compra
     */
    public String getFecha_compra() {
        return fecha_compra;
    }

    /**
     * @param fecha_compra the fecha_compra to set
     */
    public void setFecha_compra(String fecha_compra) {
        this.fecha_compra = fecha_compra;
    }

    /**
     * @return the cod_compra
     */
    public String getCod_compra() {
        return cod_compra;
    }

    /**
     * @param cod_compra the cod_compra to set
     */
    public void setCod_compra(String cod_compra) {
        this.cod_compra = cod_compra;
    }

    /**
     * @return the codigoProducto
     */
    public String getCodigoProducto() {
        return codigoProducto;
    }

    /**
     * @param codigoProducto the codigoProducto to set
     */
    public void setCodigoProducto(String codigoProducto) {
        this.codigoProducto = codigoProducto;
    }
    
    
    
}

  