public class Testing {

    
    
    
   
    public static void main(String[] args){
        
        String regex = "[0-9]+";
        String data = "2334345aaaaa";
        System.out.println(data.matches(regex));
        
    }
    
    
    
}
