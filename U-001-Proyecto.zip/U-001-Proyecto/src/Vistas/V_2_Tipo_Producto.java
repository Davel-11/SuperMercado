package Vistas;

import Controladores.Categoria_Productos_1_Con;
import Modelos.Categoria_Productros_1_mod;
import Modelos.Mod_2_Tipo_Productos;
import Modelos.Variables_datos;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

public class V_2_Tipo_Producto extends javax.swing.JFrame {            
   
    public V_2_Tipo_Producto() {
        initComponents();
    }
    
    public V_2_Tipo_Producto(String user) throws SQLException {
        initComponents();
        label_user.setText(user);  
        Show_User_In_jTable();        
    }   
    
    public void Show_User_In_jTable() throws SQLException {
        
        Mod_2_Tipo_Productos op2 = new Mod_2_Tipo_Productos();                
        ArrayList<Variables_datos> list = op2.getCategoriaProductos();        
               
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
                      
        Object[] row = new Object[4];
        for (int i = 0; i< list.size() ; i++) {                  
            row[0] = list.get(i).getCodigoCP();
            row[1] = list.get(i).getNombreCP();
            row[2] = list.get(i).getCodigoTP();
            row[3] = list.get(i).getNombreTP();            
             model.addRow(row);
        }  
        
        //----------------------------primera parte de tabla ------------//
       
        
    }
           
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txt_cod_Categoria = new javax.swing.JTextField();
        txt_nom_Categoria = new javax.swing.JTextField();
        button_add = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        button_update = new javax.swing.JButton();
        button_delete = new javax.swing.JButton();
        Button_Reg_Menu = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        label_user = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        button_find = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        txt_cod_TipoProducto = new javax.swing.JTextField();
        button_find2 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        txt_nombre_TipoProducto = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("2. ADMINISTRAR TIPO DE PRODUCTOS");

        jLabel2.setText("Ingrese Nombre Categoria");

        jLabel3.setText("Buscar/Ingresar Codigo Categoria");

        txt_nom_Categoria.setEditable(false);

        button_add.setText("Ingresar");
        button_add.setPreferredSize(new java.awt.Dimension(125, 23));
        button_add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button_addActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Codigo Categoria", "Nombre Categoria", "Codigo Tipo Producto", "Nombre Tipo Producto"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        button_update.setText("Actualizar");
        button_update.setPreferredSize(new java.awt.Dimension(125, 23));
        button_update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button_updateActionPerformed(evt);
            }
        });

        button_delete.setText("Eliminar Datos");
        button_delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button_deleteActionPerformed(evt);
            }
        });

        Button_Reg_Menu.setText("Menu Principal");
        Button_Reg_Menu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button_Reg_MenuActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Usuario:");

        label_user.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        label_user.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        label_user.setText("NombreUsuario");

        jButton1.setText("Limpiar");
        jButton1.setPreferredSize(new java.awt.Dimension(125, 23));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        button_find.setText("Buscar");
        button_find.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button_findActionPerformed(evt);
            }
        });

        jLabel5.setText("Ingrese Codigo Tipo Producto");

        button_find2.setText("Buscar");
        button_find2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button_find2ActionPerformed(evt);
            }
        });

        jLabel6.setText("Ingrese El Tipo Del Producto");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(Button_Reg_Menu, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(label_user, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(36, 36, 36))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 194, Short.MAX_VALUE)
                                                .addGap(10, 10, 10)
                                                .addComponent(txt_cod_Categoria, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(button_find, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(button_add, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addGap(50, 50, 50)
                                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(37, 37, 37)))
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(button_update, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(18, 18, 18)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(txt_nom_Categoria, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(button_delete, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(10, 10, 10)
                                        .addComponent(txt_cod_TipoProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(button_find2, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(txt_nombre_TipoProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jScrollPane1))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(28, 28, 28))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txt_cod_Categoria, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(button_find, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txt_nom_Categoria, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(button_find2, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txt_nombre_TipoProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txt_cod_TipoProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(62, 62, 62)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(button_update, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(button_delete, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(button_add, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 60, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Button_Reg_Menu, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(label_user, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(34, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Button_Reg_MenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button_Reg_MenuActionPerformed
        String user = label_user.getText();
        dispose();
        V_Menu_Principal frame = new V_Menu_Principal(user);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }//GEN-LAST:event_Button_Reg_MenuActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        int i = jTable1.getSelectedRow();
        TableModel model = jTable1.getModel();
        txt_cod_Categoria.setText(model.getValueAt(i,0).toString());
        txt_nom_Categoria.setText(model.getValueAt(i,1).toString());
        txt_cod_TipoProducto.setText(model.getValueAt(i,2).toString());
        txt_nombre_TipoProducto.setText(model.getValueAt(i,3).toString());
    }//GEN-LAST:event_jTable1MouseClicked

    private void button_addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button_addActionPerformed
        // TODO add your handling code here:
        
        String regex = "[0-9]+";
        String data = txt_cod_TipoProducto.getText();
        //System.out.println(data.matches(regex));
      
        //
        String UserInfo = label_user.getText();
        String CodigoCP = txt_cod_Categoria.getText();
        String NombreCP = txt_nom_Categoria.getText();        
        
        String CodigoTP = txt_cod_TipoProducto.getText();
        String NombreTP = txt_nombre_TipoProducto.getText();        
        
        Boolean confirmar = null;
        Boolean confirmar_regex = null;
        
        
        confirmar_regex = data.matches(regex);        
         
        if (confirmar_regex != false) {                                                  
                    try {
                        Mod_2_Tipo_Productos op = new Mod_2_Tipo_Productos(); 
                        confirmar = op.add(UserInfo, CodigoCP, NombreCP, CodigoTP, NombreTP);
                        
                        txt_cod_Categoria.setText("");
                        txt_nom_Categoria.setText("");           
                        txt_cod_TipoProducto.setText("");
                        txt_nombre_TipoProducto.setText("");
                        
                        //button_add.setSelected(false);
                            if (confirmar != false) {
                                JOptionPane.showMessageDialog(null, "Informacion agregada exitosamente");
                                DefaultTableModel model = (DefaultTableModel)jTable1.getModel(); //actualizar tabla
                                model.setRowCount(0); //actualizar tabla
                                Show_User_In_jTable(); //actualizar tabla
                            } else {
                                JOptionPane.showMessageDialog(null, "Error 005 - Codigo ya existe..");
                            }             
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
        } else {
            txt_cod_Categoria.setText("");
            txt_nom_Categoria.setText("");           
            txt_cod_TipoProducto.setText("");
            txt_nombre_TipoProducto.setText("");
            JOptionPane.showMessageDialog(null, "Error 004 - Ingrese Numeros Unicamente");
        }       
        
    }//GEN-LAST:event_button_addActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        txt_cod_Categoria.setText("");
        txt_nom_Categoria.setText("");           
        txt_cod_TipoProducto.setText("");
        txt_nombre_TipoProducto.setText("");
    }//GEN-LAST:event_jButton1ActionPerformed

    private void button_deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button_deleteActionPerformed
        // TODO add your handling code here:    
       int reply = JOptionPane.showConfirmDialog(null, "Desea Eliminar el Código? "+txt_cod_TipoProducto.getText()+"", "Eliminación", JOptionPane.YES_NO_OPTION);
        if (reply == JOptionPane.YES_OPTION) { 
                Boolean confirmar = false;
                String Codigo = txt_cod_TipoProducto.getText();
                Mod_2_Tipo_Productos op = new Mod_2_Tipo_Productos();

                try {
                     confirmar = op.Delete(Codigo);
                        txt_cod_Categoria.setText("");
                        txt_nom_Categoria.setText("");           
                        txt_cod_TipoProducto.setText("");
                        txt_nombre_TipoProducto.setText("");
                     if (confirmar != false) {                 
                            JOptionPane.showMessageDialog(null, "Informacion Eliminada exitosamente");                    
                            DefaultTableModel model = (DefaultTableModel)jTable1.getModel(); //actualizar tabla
                            model.setRowCount(0); //actualizar tabla
                            Show_User_In_jTable(); //actualizar tabla
                        } else {
                            JOptionPane.showMessageDialog(null, "Error 006 - No pudo ser Eliminado");
                        }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
        } else {
        
        }
        
        
    }//GEN-LAST:event_button_deleteActionPerformed

    private void button_updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button_updateActionPerformed
        // TODO add your handling code here:
        Boolean confirmar = false;
        String Codigo = txt_cod_TipoProducto.getText();
        String Nombre = txt_nombre_TipoProducto.getText();
        Mod_2_Tipo_Productos op = new Mod_2_Tipo_Productos();
       
        try {
                confirmar = op.Update(Codigo, Nombre);
                txt_cod_Categoria.setText("");
                txt_nom_Categoria.setText("");           
                txt_cod_TipoProducto.setText("");
                txt_nombre_TipoProducto.setText("");
             if (confirmar != false) {                 
                    JOptionPane.showMessageDialog(null, "Informacion Actualizada exitosamente");                    
                    DefaultTableModel model = (DefaultTableModel)jTable1.getModel(); //actualizar tabla
                    model.setRowCount(0); //actualizar tabla
                    Show_User_In_jTable(); //actualizar tabla
                } else {
                    JOptionPane.showMessageDialog(null, "Error 007 - No pudo ser Actualizado");
                }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }//GEN-LAST:event_button_updateActionPerformed

    private void button_findActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button_findActionPerformed
        // TODO add your handling code here:
        Categoria_Productros_1_mod op = new Categoria_Productros_1_mod();
        String codigoCP = txt_cod_Categoria.getText();
        try {            
                ArrayList<Variables_datos> list = op.findCategoriaProductos(codigoCP);                
                if(list.size()>0) {
                    txt_cod_Categoria.setText(list.get(0).getCodigoCP());
                    txt_nom_Categoria.setText(list.get(0).getNombreCP());
                } else {
                    JOptionPane.showMessageDialog(null, "El codigo no existe");
                }
                
                    } catch (SQLException ex) {
            Logger.getLogger(V_2_Tipo_Producto.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_button_findActionPerformed

    private void button_find2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button_find2ActionPerformed
        // TODO add your handling code here:
        Mod_2_Tipo_Productos op = new Mod_2_Tipo_Productos();
        String codigo = txt_cod_TipoProducto.getText();
        try {            
                ArrayList<Variables_datos> list = op.findCategoriaProductos(codigo);                
                if(list.size()>0) {
                    txt_cod_Categoria.setText(list.get(0).getCodigoCP());                    
                    txt_nom_Categoria.setText(list.get(0).getNombreCP());
                    txt_cod_TipoProducto.setText(list.get(0).getCodigoTP());
                    txt_nombre_TipoProducto.setText(list.get(0).getNombreTP());
                } else {
                    JOptionPane.showMessageDialog(null, "El codigo no existe");
                }
                
                    } catch (SQLException ex) {
            Logger.getLogger(V_2_Tipo_Producto.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_button_find2ActionPerformed

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(V_2_Tipo_Producto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(V_2_Tipo_Producto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(V_2_Tipo_Producto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(V_2_Tipo_Producto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new V_2_Tipo_Producto().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Button_Reg_Menu;
    private javax.swing.JButton button_add;
    private javax.swing.JButton button_delete;
    private javax.swing.JButton button_find;
    private javax.swing.JButton button_find2;
    private javax.swing.JButton button_update;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel label_user;
    private javax.swing.JTextField txt_cod_Categoria;
    private javax.swing.JTextField txt_cod_TipoProducto;
    private javax.swing.JTextField txt_nom_Categoria;
    private javax.swing.JTextField txt_nombre_TipoProducto;
    // End of variables declaration//GEN-END:variables
}
