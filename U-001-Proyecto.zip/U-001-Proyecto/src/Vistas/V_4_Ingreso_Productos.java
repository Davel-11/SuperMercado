package Vistas;

import Controladores.Categoria_Productos_1_Con;
import Modelos.Categoria_Productros_1_mod;
import Modelos.Mod_2_Tipo_Productos;
import Modelos.Mod_3_Fabricantes;
import Modelos.Mod_4_Productos;
import Modelos.Variables_Fabricantes;
import Modelos.Variables_datos;
import Modelos.Variables_datos_2_Fab;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

public class V_4_Ingreso_Productos extends javax.swing.JFrame {            
   
    public V_4_Ingreso_Productos() {
        initComponents();
    }
    
    public V_4_Ingreso_Productos(String user) throws SQLException {
        initComponents();
        label_user.setText(user);  
        Show_User_In_jTable();        
    }   
    
    public void Show_User_In_jTable() throws SQLException {
        
        Mod_4_Productos op2 = new Mod_4_Productos();                
        ArrayList<Variables_datos_2_Fab> list = op2.getCategoriaProductos();        
              
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
                      
        Object[] row = new Object[9];
        for (int i = 0; i< list.size() ; i++) {                  
            row[0] = list.get(i).getCodigoFab();
            row[1] = list.get(i).getNombreFab();
            row[2] = list.get(i).getCodigoTP();
            row[3] = list.get(i).getNombreTP();
            row[4] = list.get(i).getCodigo_producto();
            row[5] = list.get(i).getNombre_producto();
            row[6] = list.get(i).getPrecio_venta();
            row[7] = list.get(i).getPrecio_compra();
            row[8] = list.get(i).getNo_existencias();            
             model.addRow(row);
        }  
        
        //----------------------------primera parte de tabla ------------//
       
        
    }
   
  
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txt_cod_Fabricante = new javax.swing.JTextField();
        text_nom_Fabricante = new javax.swing.JTextField();
        button_add = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        button_update = new javax.swing.JButton();
        button_delete = new javax.swing.JButton();
        Button_Reg_Menu = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        label_user = new javax.swing.JLabel();
        jButton_Limpiar = new javax.swing.JButton();
        button_find_fabricante = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        txt_cod_TipoProducto = new javax.swing.JTextField();
        button_find_tipoProducto = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        txt_nombre_TipoProducto = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txt_cod_Producto = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txt_nombre_Producto = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txt_precio_Venta = new javax.swing.JTextField();
        txt_existencias = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        txt_precio_Compra = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("4. INGRESO DE PRODUCTOS");

        jLabel2.setText("Nombre Fabricante:");

        jLabel3.setText("Buscar/Ingresar Codigo Fabricante:");

        text_nom_Fabricante.setEditable(false);

        button_add.setText("Ingresar");
        button_add.setPreferredSize(new java.awt.Dimension(125, 23));
        button_add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button_addActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Cod Fabricante", "Nom Fabricante", "Cod Tipo Producto", "Nom Tipo Producto", "Cod Producto", "Nombre Producto", "Precio Venta", "Precio Compra", "No. Existencias"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        button_update.setText("Actualizar");
        button_update.setPreferredSize(new java.awt.Dimension(125, 23));
        button_update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button_updateActionPerformed(evt);
            }
        });

        button_delete.setText("Eliminar");
        button_delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button_deleteActionPerformed(evt);
            }
        });

        Button_Reg_Menu.setText("Menu Principal");
        Button_Reg_Menu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button_Reg_MenuActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Usuario:");

        label_user.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        label_user.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        label_user.setText("NombreUsuario");

        jButton_Limpiar.setText("Limpiar");
        jButton_Limpiar.setPreferredSize(new java.awt.Dimension(125, 23));
        jButton_Limpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_LimpiarActionPerformed(evt);
            }
        });

        button_find_fabricante.setText("Confirmar Codigo");
        button_find_fabricante.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button_find_fabricanteActionPerformed(evt);
            }
        });
        button_find_fabricante.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                button_find_fabricanteKeyPressed(evt);
            }
        });

        jLabel5.setText("Buscar/Ing Codigo Tipo Producto:");

        button_find_tipoProducto.setText("Confirmar Codigo");
        button_find_tipoProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button_find_tipoProductoActionPerformed(evt);
            }
        });
        button_find_tipoProducto.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                button_find_tipoProductoKeyPressed(evt);
            }
        });

        jLabel6.setText("Nombre Tipo Producto:");

        txt_nombre_TipoProducto.setEditable(false);

        jLabel7.setText("Ingrese Codigo del Producto:");

        jLabel8.setText("Ingrese Nombre Del Producto:");

        jLabel9.setText("Ingrese Precio Venta:");

        jLabel10.setText("Ingrese Numbero de Existencias:");

        jLabel11.setText("Ingrese Precio Compra:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(91, 91, 91)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(txt_cod_Producto, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txt_existencias, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txt_precio_Venta, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(txt_cod_Fabricante, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txt_cod_TipoProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGap(28, 28, 28))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(button_add, javax.swing.GroupLayout.DEFAULT_SIZE, 198, Short.MAX_VALUE)
                                .addGap(50, 50, 50)
                                .addComponent(jButton_Limpiar, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 91, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(162, 162, 162)
                                        .addComponent(button_find_fabricante, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(170, 170, 170)
                                        .addComponent(button_find_tipoProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(button_update, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(42, 42, 42)
                                .addComponent(button_delete, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(18, 18, 18)
                                            .addComponent(text_nom_Fabricante, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(18, 18, 18)
                                            .addComponent(txt_nombre_TipoProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(18, 18, 18)
                                            .addComponent(txt_precio_Compra, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(18, 18, 18)
                                            .addComponent(txt_nombre_Producto, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGap(75, 75, 75)))
                        .addContainerGap(23, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(Button_Reg_Menu, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(label_user, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(36, 36, 36))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(text_nom_Fabricante, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_nombre_TipoProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_nombre_Producto, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_precio_Compra, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(button_find_fabricante, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(button_find_tipoProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(txt_cod_Fabricante, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txt_cod_TipoProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txt_cod_Producto, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txt_precio_Venta, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txt_existencias, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 20, Short.MAX_VALUE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(button_update, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(button_delete, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton_Limpiar, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(button_add, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 37, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Button_Reg_Menu, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(label_user, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(30, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Button_Reg_MenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button_Reg_MenuActionPerformed
        String user = label_user.getText();
        dispose();
        V_Menu_Principal frame = new V_Menu_Principal(user);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }//GEN-LAST:event_Button_Reg_MenuActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        int i = jTable1.getSelectedRow();
        TableModel model = jTable1.getModel();
        txt_cod_Fabricante.setText(model.getValueAt(i,0).toString());
        text_nom_Fabricante.setText(model.getValueAt(i,1).toString());
        txt_cod_TipoProducto.setText(model.getValueAt(i,2).toString());
        txt_nombre_TipoProducto.setText(model.getValueAt(i,3).toString());
        
        txt_cod_Producto.setText(model.getValueAt(i,4).toString());
        txt_nombre_Producto.setText(model.getValueAt(i,5).toString());
        txt_precio_Venta.setText(model.getValueAt(i,6).toString());
        txt_precio_Compra.setText(model.getValueAt(i,7).toString());
        txt_existencias.setText(model.getValueAt(i,8).toString());
        
    }//GEN-LAST:event_jTable1MouseClicked

    private void button_addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button_addActionPerformed
        // TODO add your handling code here:              
        Boolean confirmar = null;                                                                       
               
        String regex = "^\\d+(\\.\\d+)*$";
        String regex2 = "[a-zA-Z]+";
                
        String validar1 = txt_cod_Producto.getText();        
        //String validar2 = txt_nombre_Producto.getText();        
        String validar3 = txt_precio_Venta.getText();
        String validar4 = txt_precio_Compra.getText();
        String validar5 = txt_existencias.getText();              
        
        Boolean conf_regex1 = validar1.matches(regex);     
        //Boolean conf_regex2 = validar2.matches(regex2);                   
        Boolean conf_regex3 = validar3.matches(regex);        
        Boolean conf_regex4 = validar4.matches(regex);
        Boolean conf_regex5 = validar5.matches(regex);
       
       //      if ( || validar1.isEmpty() ) { 
      
            
     if ( conf_regex1 == true && conf_regex3 == true && conf_regex4 == true && conf_regex5 == true ) { 
                    
                try {
                             //
                        String UserInfo = label_user.getText();
                        String CodigoFab = txt_cod_Fabricante.getText();
                        String NombreFab = text_nom_Fabricante.getText();                
                        String CodigoTP = txt_cod_TipoProducto.getText();
                        String NombreTP = txt_nombre_TipoProducto.getText();     
                        
                        String CodigoProducto = txt_cod_Producto.getText();
                        String NombreProducto = txt_nombre_Producto.getText(); 
                        Double PrecioVenta = Double.parseDouble(txt_precio_Venta.getText());
                        Double PrecioCompra = Double.parseDouble(txt_precio_Compra.getText());
                        int NoExistencias =  Integer.parseInt(txt_existencias.getText());      
                        
                        Mod_4_Productos op = new Mod_4_Productos(); 
                        confirmar = op.add(UserInfo, CodigoFab, NombreFab, CodigoTP, NombreTP, CodigoProducto, NombreProducto, PrecioVenta, PrecioCompra, NoExistencias);
                        
                        
                        
                        //button_add.setSelected(false);
                            if (confirmar != false) {
                                JOptionPane.showMessageDialog(null, "Informacion agregada exitosamente");
                                DefaultTableModel model = (DefaultTableModel)jTable1.getModel(); //actualizar tabla
                                txt_cod_Fabricante.setText("");
                                text_nom_Fabricante.setText("");
                                txt_cod_TipoProducto.setText("");
                                txt_nombre_TipoProducto.setText("");

                                txt_cod_Producto.setText("");
                                txt_nombre_Producto.setText("");
                                txt_precio_Venta.setText("");
                                txt_precio_Compra.setText("");
                                txt_existencias.setText("");
                                model.setRowCount(0); //actualizar tabla
                                Show_User_In_jTable(); //actualizar tabla
                            } else {
                                JOptionPane.showMessageDialog(null, "Error 005 - Codigo ya existe..");
                            }             
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
        } else {            
            JOptionPane.showMessageDialog(null, "Error Al Validar la informacion");
        }       
        
    }//GEN-LAST:event_button_addActionPerformed

    private void jButton_LimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_LimpiarActionPerformed
        // TODO add your handling code here:
        txt_cod_Fabricante.setText("");
        text_nom_Fabricante.setText("");
        txt_cod_TipoProducto.setText("");
        txt_nombre_TipoProducto.setText("");

        txt_cod_Producto.setText("");
        txt_nombre_Producto.setText("");
        txt_precio_Venta.setText("");
        txt_precio_Compra.setText("");
        txt_existencias.setText("");
    }//GEN-LAST:event_jButton_LimpiarActionPerformed

    private void button_deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button_deleteActionPerformed
        // TODO add your handling code here:    
       int reply = JOptionPane.showConfirmDialog(null, "Desea Eliminar el Código? "+txt_cod_Producto.getText()+"", "Eliminación", JOptionPane.YES_NO_OPTION);
        if (reply == JOptionPane.YES_OPTION) { 
                
                Boolean confirmar = false;
                String Codigo = txt_cod_Producto.getText();                   
                Mod_4_Productos op = new Mod_4_Productos();

                try {
                     confirmar = op.Delete(Codigo);
                                txt_cod_Fabricante.setText("");
                                text_nom_Fabricante.setText("");
                                txt_cod_TipoProducto.setText("");
                                txt_nombre_TipoProducto.setText("");

                                txt_cod_Producto.setText("");
                                txt_nombre_Producto.setText("");
                                txt_precio_Venta.setText("");
                                txt_precio_Compra.setText("");
                                txt_existencias.setText("");
                     if (confirmar != false) {                 
                            JOptionPane.showMessageDialog(null, "Informacion Eliminada exitosamente");                    
                            DefaultTableModel model = (DefaultTableModel)jTable1.getModel(); //actualizar tabla
                            model.setRowCount(0); //actualizar tabla
                            Show_User_In_jTable(); //actualizar tabla
                        } else {
                            JOptionPane.showMessageDialog(null, "Error 006 - No pudo ser Eliminado");
                        }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
        } else {
        
        }
        
        
    }//GEN-LAST:event_button_deleteActionPerformed

    private void button_updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button_updateActionPerformed
        // TODO add your handling code here:
        Boolean confirmar = false;
                        String UserInfo = label_user.getText();
                        String CodigoFab = txt_cod_Fabricante.getText();
                        String NombreFab = text_nom_Fabricante.getText();                
                        String CodigoTP = txt_cod_TipoProducto.getText();
                        String NombreTP = txt_nombre_TipoProducto.getText();     
                        
                        String CodigoProducto = txt_cod_Producto.getText();
                        String NombreProducto = txt_nombre_Producto.getText(); 
                        Double PrecioVenta = Double.parseDouble(txt_precio_Venta.getText());
                        Double PrecioCompra = Double.parseDouble(txt_precio_Compra.getText());
                        int NoExistencias =  Integer.parseInt(txt_existencias.getText());  
        
                        Mod_4_Productos op = new Mod_4_Productos();
       
        try {
                confirmar = op.Update(UserInfo, CodigoFab, NombreFab, CodigoTP, NombreTP, CodigoProducto, NombreProducto, PrecioVenta, PrecioCompra, NoExistencias);
                                
                                txt_cod_Fabricante.setText("");
                                text_nom_Fabricante.setText("");
                                txt_cod_TipoProducto.setText("");
                                txt_nombre_TipoProducto.setText("");

                                txt_cod_Producto.setText("");
                                txt_nombre_Producto.setText("");
                                txt_precio_Venta.setText("");
                                txt_precio_Compra.setText("");
                                txt_existencias.setText("");
                                
             if (confirmar != false) {                 
                    JOptionPane.showMessageDialog(null, "Informacion Actualizada exitosamente");                    
                    DefaultTableModel model = (DefaultTableModel)jTable1.getModel(); //actualizar tabla
                    model.setRowCount(0); //actualizar tabla
                    Show_User_In_jTable(); //actualizar tabla
                } else {
                    JOptionPane.showMessageDialog(null, "Error 007 - No pudo ser Actualizado");
                }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }//GEN-LAST:event_button_updateActionPerformed

    private void button_find_fabricanteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button_find_fabricanteActionPerformed
        // TODO add your handling code here:
        Mod_3_Fabricantes op = new Mod_3_Fabricantes();
        String codigo = txt_cod_Fabricante.getText();
        try {            
                ArrayList<Variables_Fabricantes> list = op.findCategoriaProductos(codigo);                
                if(list.size()>0) {
                    txt_cod_Fabricante.setText(list.get(0).getCodigoFab());
                    text_nom_Fabricante.setText(list.get(0).getNombreFab());
                } else {
                    JOptionPane.showMessageDialog(null, "Error 003 - El Codigo No Existe");
                }
                
                    } catch (SQLException ex) {
            Logger.getLogger(V_4_Ingreso_Productos.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_button_find_fabricanteActionPerformed

    private void button_find_tipoProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button_find_tipoProductoActionPerformed
        // TODO add your handling code here:
        Mod_2_Tipo_Productos op = new Mod_2_Tipo_Productos();
        String codigo = txt_cod_TipoProducto.getText();
        try {            
                ArrayList<Variables_datos> list = op.findCategoriaProductos(codigo);                
                if(list.size()>0) {
                    txt_cod_TipoProducto.setText(list.get(0).getCodigoTP());
                    txt_nombre_TipoProducto.setText(list.get(0).getNombreTP());
                } else {
                    JOptionPane.showMessageDialog(null, "Error 003 - El Codigo No Existe");
                }
                
                    } catch (SQLException ex) {
            Logger.getLogger(V_4_Ingreso_Productos.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_button_find_tipoProductoActionPerformed

    private void button_find_fabricanteKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_button_find_fabricanteKeyPressed
        Mod_3_Fabricantes op = new Mod_3_Fabricantes();
        String codigo = txt_cod_Fabricante.getText();
        try {            
                ArrayList<Variables_Fabricantes> list = op.findCategoriaProductos(codigo);                
                if(list.size()>0) {
                    txt_cod_Fabricante.setText(list.get(0).getCodigoFab());
                    text_nom_Fabricante.setText(list.get(0).getNombreFab());
                } else {
                    JOptionPane.showMessageDialog(null, "Error 003 - El Codigo No Existe");
                }
                
                    } catch (SQLException ex) {
            Logger.getLogger(V_4_Ingreso_Productos.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_button_find_fabricanteKeyPressed

    private void button_find_tipoProductoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_button_find_tipoProductoKeyPressed
        // TODO add your handling code here:
        Mod_2_Tipo_Productos op = new Mod_2_Tipo_Productos();
        String codigo = txt_cod_TipoProducto.getText();
        try {            
                ArrayList<Variables_datos> list = op.findCategoriaProductos(codigo);                
                if(list.size()>0) {
                    txt_cod_TipoProducto.setText(list.get(0).getCodigoTP());
                    txt_nombre_TipoProducto.setText(list.get(0).getNombreTP());
                } else {
                    JOptionPane.showMessageDialog(null, "Error 003 - El Codigo No Existe");
                }
                
                    } catch (SQLException ex) {
            Logger.getLogger(V_4_Ingreso_Productos.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_button_find_tipoProductoKeyPressed

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(V_4_Ingreso_Productos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(V_4_Ingreso_Productos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(V_4_Ingreso_Productos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(V_4_Ingreso_Productos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new V_4_Ingreso_Productos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Button_Reg_Menu;
    private javax.swing.JButton button_add;
    private javax.swing.JButton button_delete;
    private javax.swing.JButton button_find_fabricante;
    private javax.swing.JButton button_find_tipoProducto;
    private javax.swing.JButton button_update;
    private javax.swing.JButton jButton_Limpiar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel label_user;
    private javax.swing.JTextField text_nom_Fabricante;
    private javax.swing.JTextField txt_cod_Fabricante;
    private javax.swing.JTextField txt_cod_Producto;
    private javax.swing.JTextField txt_cod_TipoProducto;
    private javax.swing.JTextField txt_existencias;
    private javax.swing.JTextField txt_nombre_Producto;
    private javax.swing.JTextField txt_nombre_TipoProducto;
    private javax.swing.JTextField txt_precio_Compra;
    private javax.swing.JTextField txt_precio_Venta;
    // End of variables declaration//GEN-END:variables
}
