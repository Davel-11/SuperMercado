package Vistas;

import Controladores.Categoria_Productos_1_Con;
import Modelos.Categoria_Productros_1_mod;
import Modelos.Mod_2_Tipo_Productos;
import Modelos.Mod_7_Clientes;
import Modelos.Variables_Clientes;
import Modelos.Variables_datos;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

public class V_7_Clientes extends javax.swing.JFrame {            
   
    public V_7_Clientes() {
        initComponents();
    }
    
    public V_7_Clientes(String user) throws SQLException {
        initComponents();
        label_user.setText(user);  
        Show_User_In_jTable();        
    }   
    
    public void Show_User_In_jTable() throws SQLException {
        
        Mod_7_Clientes op2 = new Mod_7_Clientes();                
        ArrayList<Variables_Clientes> list = op2.getClientes();        
               
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
                      
        Object[] row = new Object[5];
        for (int i = 0; i< list.size() ; i++) {                  
            row[0] = list.get(i).getNitCliente();
            row[1] = list.get(i).getNomCliente();
            row[2] = list.get(i).getApeCliente();
            row[3] = list.get(i).getTelCliente();
            row[4] = list.get(i).getDirCliente();
             model.addRow(row);
        }  
        
        //----------------------------primera parte de tabla ------------//
       
        
    }
           
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txt_nit = new javax.swing.JTextField();
        txt_nom_cliente = new javax.swing.JTextField();
        button_add = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        button_update = new javax.swing.JButton();
        button_delete = new javax.swing.JButton();
        Button_Reg_Menu = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        label_user = new javax.swing.JLabel();
        CleanData = new javax.swing.JButton();
        button_find = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        txt_ape_cliente = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txt_tel = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txt_dir = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("7. ADMINISTRAR CLIENTES");

        jLabel2.setText("Nombre:");

        jLabel3.setText("Nit Cliente:");

        button_add.setText("Ingresar");
        button_add.setPreferredSize(new java.awt.Dimension(125, 23));
        button_add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button_addActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nit", "Nombre(s)", "Apelllidos(s)", "Telefono", "Direccion"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        button_update.setText("Actualizar");
        button_update.setPreferredSize(new java.awt.Dimension(125, 23));
        button_update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button_updateActionPerformed(evt);
            }
        });

        button_delete.setText("Eliminar Datos");
        button_delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button_deleteActionPerformed(evt);
            }
        });

        Button_Reg_Menu.setText("Menu Principal");
        Button_Reg_Menu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Button_Reg_MenuActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Usuario:");

        label_user.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        label_user.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        label_user.setText("NombreUsuario");

        CleanData.setText("Limpiar");
        CleanData.setPreferredSize(new java.awt.Dimension(125, 23));
        CleanData.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CleanDataActionPerformed(evt);
            }
        });

        button_find.setText("Buscar");
        button_find.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                button_findActionPerformed(evt);
            }
        });

        jLabel5.setText("Apellidos:");

        jLabel6.setText("Telefono:");

        jLabel7.setText("Direccion:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(Button_Reg_Menu, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(label_user, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(36, 36, 36))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 194, Short.MAX_VALUE)
                                                .addGap(10, 10, 10)
                                                .addComponent(txt_nit, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(button_find, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                .addComponent(button_add, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addGap(50, 50, 50)
                                                .addComponent(CleanData, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(37, 37, 37))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(txt_nom_cliente)
                                                    .addComponent(txt_ape_cliente))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(button_update, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(42, 42, 42)
                                                .addComponent(button_delete, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(txt_tel, javax.swing.GroupLayout.PREFERRED_SIZE, 278, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                    .addComponent(jScrollPane1)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(txt_dir, javax.swing.GroupLayout.PREFERRED_SIZE, 599, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(28, 28, 28))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txt_nit, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(button_find, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txt_tel, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_nom_cliente, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_ape_cliente, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_dir, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(button_update, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(button_delete, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CleanData, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(button_add, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Button_Reg_Menu, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(label_user, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(34, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Button_Reg_MenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Button_Reg_MenuActionPerformed
        String user = label_user.getText();
        dispose();
        V_Menu_Principal frame = new V_Menu_Principal(user);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }//GEN-LAST:event_Button_Reg_MenuActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        int i = jTable1.getSelectedRow();
        TableModel model = jTable1.getModel();
        
        txt_nit.setText(model.getValueAt(i,0).toString());
        txt_nom_cliente.setText(model.getValueAt(i,1).toString());
        txt_ape_cliente.setText(model.getValueAt(i,2).toString());
        txt_tel.setText(model.getValueAt(i,3).toString());
        txt_dir.setText(model.getValueAt(i,4).toString());
    }//GEN-LAST:event_jTable1MouseClicked

    private void button_addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button_addActionPerformed
        // TODO add your handling code here:
        
        String regex = "[0-9]+";
       
        String data = txt_nit.getText();
        
        String user = label_user.getText();
        String nitCliente = txt_nit.getText();
        String nomCliente = txt_nom_cliente.getText();
        String apeCliente = txt_ape_cliente  .getText();        
        String telCliente = txt_tel.getText();
        String dirCliente  = txt_dir.getText();  
        
        Boolean confirmar = null;
        Boolean confirmar_regex = null;
        
        
        confirmar_regex = data.matches(regex);        
         
        if (confirmar_regex != false) {                                                  
                    try {
                        Mod_7_Clientes op = new Mod_7_Clientes(); 
                        confirmar = op.add(user, nitCliente, nomCliente, apeCliente, telCliente, dirCliente);
                        
                        txt_nit.setText("");
                        txt_nom_cliente.setText("");
                        txt_ape_cliente.setText("");       
                        txt_tel.setText("");
                        txt_dir.setText(""); 
                        
                        //button_add.setSelected(false);
                            if (confirmar != false) {
                                JOptionPane.showMessageDialog(null, "Informacion agregada exitosamente");
                                DefaultTableModel model = (DefaultTableModel)jTable1.getModel(); //actualizar tabla
                                model.setRowCount(0); //actualizar tabla
                                Show_User_In_jTable(); //actualizar tabla
                            } else {
                                JOptionPane.showMessageDialog(null, "Error 005 - Nit ya existe..");
                            }             
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
        } else {
            txt_nit.setText("");
                       
            JOptionPane.showMessageDialog(null, "Error 004 - Ingrese Numeros Unicamente");
        }       
        
    }//GEN-LAST:event_button_addActionPerformed

    private void CleanDataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CleanDataActionPerformed
        // TODO add your handling code here:
        txt_nit.setText("");
        txt_nom_cliente.setText("");           
        txt_ape_cliente.setText("");
        txt_tel.setText("");
        txt_dir.setText("");
    }//GEN-LAST:event_CleanDataActionPerformed

    private void button_deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button_deleteActionPerformed
        // TODO add your handling code here:    
       int reply = JOptionPane.showConfirmDialog(null, "Desea Eliminar el Cliente con el Nit? "+txt_nit.getText()+"", "Eliminación", JOptionPane.YES_NO_OPTION);
        if (reply == JOptionPane.YES_OPTION) { 
                Boolean confirmar = false;
                String Codigo = txt_nit.getText();
                Mod_7_Clientes op = new Mod_7_Clientes();

                try {
                        confirmar = op.Delete(Codigo);
                        txt_nit.setText("");
                        txt_nom_cliente.setText("");           
                        txt_ape_cliente.setText("");
                        txt_tel.setText("");
                        txt_dir.setText("");
                     if (confirmar != false) {                 
                            JOptionPane.showMessageDialog(null, "Informacion Eliminada exitosamente");                    
                            DefaultTableModel model = (DefaultTableModel)jTable1.getModel(); //actualizar tabla
                            model.setRowCount(0); //actualizar tabla
                            Show_User_In_jTable(); //actualizar tabla
                        } else {
                            JOptionPane.showMessageDialog(null, "Error 006 - No pudo ser Eliminado");
                        }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
        } else {
        
        }
        
        
    }//GEN-LAST:event_button_deleteActionPerformed

    private void button_updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button_updateActionPerformed
        // TODO add your handling code here:
        Boolean confirmar = false;
        
        String user = label_user.getText();
        String nitCliente = txt_nit.getText();
        String nomCliente = txt_nom_cliente.getText();
        String apeCliente = txt_ape_cliente  .getText();        
        String telCliente = txt_tel.getText();
        String dirCliente  = txt_dir.getText();  
        Mod_7_Clientes op = new Mod_7_Clientes();
       
        try {
                confirmar = op.Update(user, nitCliente, nomCliente, apeCliente, telCliente, dirCliente);
                
             if (confirmar != false) {                 
                    JOptionPane.showMessageDialog(null, "Informacion Actualizada exitosamente");     
                    txt_nit.setText("");
                    txt_nom_cliente.setText("");           
                    txt_ape_cliente.setText("");
                    txt_tel.setText("");
                    txt_dir.setText("");
                    DefaultTableModel model = (DefaultTableModel)jTable1.getModel(); //actualizar tabla
                    model.setRowCount(0); //actualizar tabla
                    Show_User_In_jTable(); //actualizar tabla
                } else {
                    JOptionPane.showMessageDialog(null, "Error 007 - No pudo ser Actualizado");
                }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }//GEN-LAST:event_button_updateActionPerformed

    private void button_findActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_button_findActionPerformed
        // TODO add your handling code here:
        Mod_7_Clientes op = new Mod_7_Clientes();
        String codigo = txt_nit.getText();
        try {            
                ArrayList<Variables_Clientes> list = op.findCliente(codigo);                
                if(list.size()>0) {
                    txt_nit.setText(list.get(0).getNitCliente());
                    txt_nom_cliente.setText(list.get(0).getNomCliente());
                    txt_ape_cliente.setText(list.get(0).getApeCliente());
                    txt_tel.setText(list.get(0).getTelCliente());
                    txt_dir.setText(list.get(0).getDirCliente());
                    
                } else {
                    JOptionPane.showMessageDialog(null, "El codigo no existe");
                }
                
                    } catch (SQLException ex) {
            Logger.getLogger(V_7_Clientes.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_button_findActionPerformed

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(V_7_Clientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(V_7_Clientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(V_7_Clientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(V_7_Clientes.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new V_7_Clientes().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Button_Reg_Menu;
    private javax.swing.JButton CleanData;
    private javax.swing.JButton button_add;
    private javax.swing.JButton button_delete;
    private javax.swing.JButton button_find;
    private javax.swing.JButton button_update;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel label_user;
    private javax.swing.JTextField txt_ape_cliente;
    private javax.swing.JTextField txt_dir;
    private javax.swing.JTextField txt_nit;
    private javax.swing.JTextField txt_nom_cliente;
    private javax.swing.JTextField txt_tel;
    // End of variables declaration//GEN-END:variables
}
