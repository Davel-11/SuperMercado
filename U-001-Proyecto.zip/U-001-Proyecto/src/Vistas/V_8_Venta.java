package Vistas;

import Modelos.Mod_7_Clientes;
import Modelos.Mod_8_venta;
import Modelos.Variables_Clientes;
import Modelos.Variables_Factura;
import Modelos.Variables_Venta;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Box;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.util.*;

public class V_8_Venta extends javax.swing.JFrame {

    public V_8_Venta() {
        initComponents();
    }

    public V_8_Venta(String User) {        
        initComponents();    
        label_user.setText(User);
        
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("MMMM-dd-yyyy - hh:mm");        
        FechaCompra.setText(sdf.format(date));
    }       
     
    public void venta(){
        Mod_8_venta op = new Mod_8_venta();
        ArrayList<Variables_Venta> lista = new ArrayList<Variables_Venta>();
        String codigo = codProducto.getText();
                
        try {
            lista = op.getVenta(codigo);            
            
            if (lista.size() > 0) {

                nomProducto.setText(lista.get(0).getNombre());          
                Double preciox = lista.get(0).getPrecio();            
                precio.setText(preciox.toString());

                int cantidad = Integer.parseInt(jSpinner1.getValue().toString());
                Double subtotal2 = cantidad * preciox;
                subTotal.setText(subtotal2.toString()); 
            
            } else {
                JOptionPane.showMessageDialog(null, "El codigo No existe!");
            }
                       
            
        } catch (SQLException ex) {
            Logger.getLogger(V_8_Venta.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void Total(){
        Double Total = 0.00;
            for (int i=0; i < jTable1.getRowCount();i++) {
                Total = Total + Double.parseDouble(jTable1.getValueAt(i,4).toString());                
            }
            totalCompra.setText(Total.toString());   
    }
    
    public void agregar(){
            String codigo1 = codProducto.getText();
            Double validar =  Double.parseDouble(precio.getText().toString());
            if ( !codigo1.isEmpty() && validar > 0 ) {
                
                String nombre1 = nomProducto.getText();
                float precio1 = Float.parseFloat(precio.getText().toString());
                int cantidad1 = Integer.parseInt(jSpinner1.getValue().toString());
                float  subtotal1 = Float.parseFloat(subTotal.getText());

                DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
                Object[] row = new Object[5];                        
                row[0] = codigo1;
                row[1] = nombre1;
                row[2] = precio1;
                row[3] = cantidad1;
                row[4] = subtotal1;
                model.addRow(row);   

                codProducto.setText("");
                nomProducto.setText("---");
                precio.setText("0.00");
                jSpinner1.setValue(1);
                subTotal.setText("0.00");
                
                codProducto.requestFocus();
                Total();
                
            } else {
                JOptionPane.showMessageDialog(null, "Codigo Erroneo");     
            }
    }
    
    public void FindCliente(){
        String buscarnit = txt_nit.getText();
        Mod_7_Clientes op = new Mod_7_Clientes();
        ArrayList<Variables_Clientes> lista = new ArrayList<Variables_Clientes>();
        
        try {
            lista = op.findCliente(buscarnit);
            if (!lista.isEmpty()) {
                txt_nit.setText(lista.get(0).getNitCliente());
                txt_nombre.setText(lista.get(0).getNomCliente()+" "+lista.get(0).getApeCliente());
            } else {
                    int reply = JOptionPane.showConfirmDialog(null, "El cliente no Existe desea agregarlo?", "Confirmacion", JOptionPane.YES_NO_OPTION);
                    if (reply == JOptionPane.YES_OPTION) { 
                            txt_nit.setText("");
                            txt_nombre.setText("");
                           String user = label_user.getText();
                            dispose();
                            V_7_Clientes frame = null;
                            try {
                                frame = new V_7_Clientes(user);
                            } catch (SQLException ex) {
                                Logger.getLogger(V_Menu_Principal.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            frame.pack();
                            frame.setLocationRelativeTo(null);
                            frame.setVisible(true);
                    } else {txt_nit.setText("");
                            txt_nombre.setText("");}
            }
        } catch (SQLException ex) {
            Logger.getLogger(V_8_Venta.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    public void Imprimir() throws SQLException{
        
        //datos de Factura
        String noFactura = txt_fac.getText();
        String ifecha = FechaCompra.getText();
        String itienda = FechaCompra1.getText();
        String init = txt_nit.getText();
        String iname = txt_nombre.getText();
        
        // datos de venta
        String itotal = totalCompra.getText();                        
        String itipoPago = jComboBox1.getSelectedItem().toString();
        Double iMontoPagar = Double.parseDouble(MontoPagar.getText());
        Double iCambio = Double.parseDouble(Cambio.getText());
        
        //System.out.println(itipoPago);
        
        //datos de productos
        String[][] dato = new String[jTable1.getRowCount()][jTable1.getColumnCount()];
        for (int i=0; i < jTable1.getRowCount();i++){
            for (int j=0; j < jTable1.getColumnCount();j++){
                dato[i][j] = jTable1.getValueAt(i,j).toString();
         }
        }
                        
        
        
        
        // Imprimir Facura
        PrintWriter pw = null;
        try {
            pw = new PrintWriter(new FileWriter("out.txt"));
        } catch (IOException ex) {
            Logger.getLogger(V_8_Venta.class.getName()).log(Level.SEVERE, null, ex);
        }
        pw.write("Factura No: "+noFactura);pw.println();
        pw.write("Fecha: "+ifecha);pw.println();
        pw.write("Tienda:"+itienda);pw.println();
        pw.write("Nit: "+init);pw.println();
        pw.write("Nombre: "+iname);pw.println();
        pw.write("----------------------");pw.println();
        
        // datos de venta
        pw.write("Total Cancelado: "+itotal);pw.println();
        pw.write("Metodo de Pago: "+itipoPago);pw.println();
        pw.write("Monto Cancelado: "+iMontoPagar);pw.println();
        pw.write("Cambio : "+iCambio);pw.println();               
        pw.write("----------------------");pw.println();
        
         
        pw.write("Su Compra:");pw.println();
        for (int i=0; i <dato.length ;i++){
            //for (int j=0; j < dato[0].length;j++){
                pw.write("codigo: "+dato[i][0]+" Nombe: "+dato[i][1]+" Precio: "+dato[i][2]+" Unidades: "+dato[i][3]+" Subtotal: "+dato[i][4]);
                //}
            pw.println();
        }
        pw.write("******************");
        pw.println();pw.println();
        pw.write("Gracias por Preferirnos");pw.println();
        pw.close();
        
            
        
        // ir a traer existencias....
        //System.out.println("en bodega: ");
        Mod_8_venta op2 =  new Mod_8_venta();
        ArrayList<Variables_Venta> existencias = new ArrayList<>();
        String codigo = "";
        int exist;
        //******* INSTANCIAR 
        
        //existencias =  op2.getVenta(dato[0][0]);
        /*for (int n = 0; n < dato.length ; n++ ) {
                codigo = dato[n][0];
                existencias = op2.getVenta(codigo);
                exist = existencias.get(0).getNoExistencias();
                System.out.println(exist);
        }
        
        System.out.println("En Venta: ");
        for (int i =0; i < dato.length; i++) {
            System.out.println(dato[i][3]);
        }*/
        
        System.out.println("Re ingresar al base de datos:");
        int nuevaExistecia;
        int exist2;
        for (int n = 0; n < dato.length ; n++ ) {
                codigo = dato[n][0];
                existencias = op2.getVenta(codigo);
                exist = existencias.get(0).getNoExistencias();
                //System.out.println(exist);
                exist2 = Integer.parseInt(dato[n][3]);
                nuevaExistecia = exist - exist2;
               // System.out.println(nuevaExistecia); 
                op2.Update(codigo, nuevaExistecia);
        }
        
        
        
        

    }
    
    
    
    
    
    
     
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        codProducto = new javax.swing.JTextField();
        nomProducto = new javax.swing.JTextField();
        precio = new javax.swing.JTextField();
        subTotal = new javax.swing.JTextField();
        BuscarCodigo = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jSpinner1 = new javax.swing.JSpinner();
        agregarPro = new javax.swing.JButton();
        Elminar = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel12 = new javax.swing.JLabel();
        totalCompra = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        MontoPagar = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        Cambio = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        visa = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txt_nit = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        txt_nombre = new javax.swing.JTextField();
        txt_fac = new javax.swing.JTextField();
        FechaCompra1 = new javax.swing.JTextField();
        FechaCompra = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        label_user = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("Codigo Producto");

        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("Nombre Producto");

        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("Precio");

        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("No. Articulos");

        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setText("SubTotal");

        codProducto.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        codProducto.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        nomProducto.setEditable(false);
        nomProducto.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        nomProducto.setForeground(new java.awt.Color(51, 204, 0));
        nomProducto.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        nomProducto.setText("---");

        precio.setEditable(false);
        precio.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        precio.setForeground(new java.awt.Color(51, 204, 0));
        precio.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        precio.setText("0.00");

        subTotal.setEditable(false);
        subTotal.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        subTotal.setForeground(new java.awt.Color(0, 204, 0));
        subTotal.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        subTotal.setText("0.00");
        subTotal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                subTotalActionPerformed(evt);
            }
        });

        BuscarCodigo.setText("Buscar");
        BuscarCodigo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BuscarCodigoActionPerformed(evt);
            }
        });
        BuscarCodigo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                BuscarCodigoKeyPressed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Codigo Producto", "Nombre", "Precio", "No. Articulos", "Subtotal"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jSpinner1.setValue(1);
        jSpinner1.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jSpinner1StateChanged(evt);
            }
        });
        jSpinner1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jSpinner1FocusGained(evt);
            }
        });
        jSpinner1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jSpinner1KeyPressed(evt);
            }
        });

        agregarPro.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        agregarPro.setForeground(new java.awt.Color(51, 51, 255));
        agregarPro.setText("Agregar al Carrito");
        agregarPro.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                agregarProStateChanged(evt);
            }
        });
        agregarPro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                agregarProActionPerformed(evt);
            }
        });
        agregarPro.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                agregarProKeyPressed(evt);
            }
        });

        Elminar.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Elminar.setForeground(new java.awt.Color(255, 51, 51));
        Elminar.setText("Eliminar De Carrito");
        Elminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ElminarActionPerformed(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(153, 153, 255));

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Efectivo", "Master Card", "Visa", "Cheque" }));

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel12.setText("Total");

        totalCompra.setEditable(false);
        totalCompra.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        totalCompra.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        totalCompra.setText("0.00");
        totalCompra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                totalCompraActionPerformed(evt);
            }
        });

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel14.setText("Monto a Pagar:");

        MontoPagar.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        MontoPagar.setText("0.00");
        MontoPagar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                MontoPagarMouseClicked(evt);
            }
        });
        MontoPagar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MontoPagarActionPerformed(evt);
            }
        });
        MontoPagar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                MontoPagarKeyPressed(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel15.setText("Cambio:");

        Cambio.setForeground(new java.awt.Color(51, 51, 255));
        Cambio.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        Cambio.setText("0.00");

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel16.setText("FACTURACION");

        visa.setText("Pagar");
        visa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                visaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(visa, javax.swing.GroupLayout.DEFAULT_SIZE, 222, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(Cambio, javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel15, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(MontoPagar, javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel14, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jComboBox1, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(totalCompra, javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel12, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel16, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 222, Short.MAX_VALUE)))
                .addGap(25, 25, 25))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(totalCompra, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(MontoPagar, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Cambio, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(visa, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel2.setBackground(new java.awt.Color(204, 204, 204));

        jLabel2.setText("No. Factura");

        jLabel13.setText("No. Tienda:");

        jLabel3.setText("Fecha");

        jLabel4.setText("Nit");

        txt_nit.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt_nit.setText("C/F");
        txt_nit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt_nitMouseClicked(evt);
            }
        });

        jButton1.setText("Buscar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jButton1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jButton1KeyPressed(evt);
            }
        });

        jLabel5.setText("Nombre");

        txt_nombre.setEditable(false);
        txt_nombre.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        txt_fac.setText("#001");

        FechaCompra1.setText("#15, Zona 1, 10 Ave, 8 Calle");

        FechaCompra.setText("0/0/00");

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Ventas");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 454, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(txt_nombre))
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(txt_fac, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(FechaCompra1, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 135, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addComponent(txt_nit)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton1))
                            .addComponent(FechaCompra, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_fac, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(FechaCompra1)
                        .addGap(6, 6, 6)))
                .addGap(5, 5, 5)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(FechaCompra, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txt_nit, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(204, 204, 204));

        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Usuario:");

        label_user.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        label_user.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        label_user.setText("NombreUsuario");

        jButton3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton3.setText("Regresar  Menu");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 51, 51));
        jButton4.setText("Cancelar");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(label_user, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 138, Short.MAX_VALUE)
                    .addComponent(jButton4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(74, 74, 74)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(label_user, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(codProducto))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(BuscarCodigo)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(nomProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addGap(8, 8, 8)
                                        .addComponent(precio, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jSpinner1)
                                    .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(agregarPro, javax.swing.GroupLayout.DEFAULT_SIZE, 164, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(subTotal)
                                    .addComponent(Elminar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 212, Short.MAX_VALUE)))))
                    .addComponent(jScrollPane1))
                .addGap(22, 22, 22))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(codProducto, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(nomProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(precio, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(subTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jSpinner1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(BuscarCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Elminar, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(agregarPro, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        String user = label_user.getText();
        dispose();
        V_Menu_Principal frame = new V_Menu_Principal(user);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void subTotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_subTotalActionPerformed
       
    }//GEN-LAST:event_subTotalActionPerformed

    private void BuscarCodigoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BuscarCodigoActionPerformed
        // TODO add your handling code here:
        venta();
    }//GEN-LAST:event_BuscarCodigoActionPerformed

    private void jSpinner1StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jSpinner1StateChanged
        // TODO add your handling code here:
        Mod_8_venta op = new Mod_8_venta();       
        ArrayList<Variables_Venta> lista = new ArrayList<Variables_Venta>();
        String codigo = codProducto.getText();
                
        try {
            
            lista = op.getVenta(codigo);                        
            if (lista.size() > 0) {
                
                Double preciox = lista.get(0).getPrecio();                            
                precio.setText(preciox.toString());
                int cantidad = Integer.parseInt(jSpinner1.getValue().toString());
                Double subtotal2 = cantidad * preciox;
                subTotal.setText(subtotal2.toString());            
             }       
            
        } catch (SQLException ex) {
            Logger.getLogger(V_8_Venta.class.getName()).log(Level.SEVERE, null, ex);
        }      
    }//GEN-LAST:event_jSpinner1StateChanged

    private void BuscarCodigoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_BuscarCodigoKeyPressed
        // TODO add your handling code here:
        venta();
    }//GEN-LAST:event_BuscarCodigoKeyPressed

    private void agregarProActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_agregarProActionPerformed
        // TODO add your handling code here:    
            agregar();            
            //System.out.println("columas: "+jTable1.getColumnCount());
            //System.out.println("filas: "+jTable1.getRowCount());
            //System.out.println("->"+jTable1.getValueAt(0,4));                      
                     
            
    }//GEN-LAST:event_agregarProActionPerformed

    private void jSpinner1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jSpinner1KeyPressed
        // TODO add your handling code here:
        jSpinner1.setValue(0);
    }//GEN-LAST:event_jSpinner1KeyPressed

    private void agregarProStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_agregarProStateChanged
        // TODO add your handling code here:
      
    }//GEN-LAST:event_agregarProStateChanged

    private void agregarProKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_agregarProKeyPressed
        // TODO add your handling code here:
        agregar();
    }//GEN-LAST:event_agregarProKeyPressed

    private void jSpinner1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jSpinner1FocusGained
        // TODO add your handling code here:
        //jSpinner1.setValue(0);
    }//GEN-LAST:event_jSpinner1FocusGained

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
                
    }//GEN-LAST:event_jTable1MouseClicked

    private void ElminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ElminarActionPerformed
        // TODO add your handling code here:
       int reply = JOptionPane.showConfirmDialog(null, "Desea Eliminar el Producto?", "Eliminación", JOptionPane.YES_NO_OPTION);
        if (reply == JOptionPane.YES_OPTION) { 
            
            //int i = jTable1.getSelectedRow();                
            //DefaultTableModel model = (DefaultTableModel)jTable1.getModel(); 
            //model.setRowCount(0); 
            
           // DefaultTableModel model = (DefaultTableModel)jTable1.getModel(); //actualizar tabla
            //model.setRowCount(1); //actualizar tabla
            
                    int row = jTable1.getSelectedRow();
                    DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
                    model.removeRow( row );
           
                    Total();
        } else {
            
        }       
    }//GEN-LAST:event_ElminarActionPerformed

    private void totalCompraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_totalCompraActionPerformed
        
    }//GEN-LAST:event_totalCompraActionPerformed

    private void visaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_visaActionPerformed
        try {
            // TODO add your handling code here:
            int reply = JOptionPane.showConfirmDialog(null, "Desea Realizar la Venta?", "Ventas", JOptionPane.YES_NO_OPTION);
        if (reply == JOptionPane.YES_OPTION) { 
            Imprimir();            
            JOptionPane.showMessageDialog(null, "Gracias por su Compra!");
            
            String user = label_user.getText();
            dispose();
            V_Menu_Principal frame = new V_Menu_Principal(user);
            frame.pack();
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
            
        }
            
        } catch (SQLException ex) {
            Logger.getLogger(V_8_Venta.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }//GEN-LAST:event_visaActionPerformed

    private void jButton1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jButton1KeyPressed
        // TODO add your handling code here:
        FindCliente();
    }//GEN-LAST:event_jButton1KeyPressed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        FindCliente();

    }//GEN-LAST:event_jButton1ActionPerformed

    private void txt_nitMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt_nitMouseClicked
        // TODO add your handling code here:
        txt_nit.setText("");
    }//GEN-LAST:event_txt_nitMouseClicked

    private void MontoPagarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MontoPagarMouseClicked
        // TODO add your handling code here:
        MontoPagar.setText("");        
    }//GEN-LAST:event_MontoPagarMouseClicked

    private void MontoPagarKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_MontoPagarKeyPressed
        // TODO add your handling code here:                                     
        if (!MontoPagar.getText().isEmpty()) {         
            
                Double MontoaPagar = Double.parseDouble(MontoPagar.getText());             
                Double iCambio = MontoaPagar - Double.parseDouble(totalCompra.getText());
                Cambio.setText(iCambio.toString());
      }
       
    }//GEN-LAST:event_MontoPagarKeyPressed

    private void MontoPagarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MontoPagarActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_MontoPagarActionPerformed

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(V_8_Venta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(V_8_Venta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(V_8_Venta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(V_8_Venta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
               // new V_8_Venta().setVisible(true);
                V_8_Venta frame = new V_8_Venta();
                frame.pack();
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BuscarCodigo;
    private javax.swing.JTextField Cambio;
    private javax.swing.JButton Elminar;
    private javax.swing.JTextField FechaCompra;
    private javax.swing.JTextField FechaCompra1;
    private javax.swing.JTextField MontoPagar;
    private javax.swing.JButton agregarPro;
    private javax.swing.JTextField codProducto;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSpinner jSpinner1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel label_user;
    private javax.swing.JTextField nomProducto;
    private javax.swing.JTextField precio;
    private javax.swing.JTextField subTotal;
    private javax.swing.JTextField totalCompra;
    private javax.swing.JTextField txt_fac;
    private javax.swing.JTextField txt_nit;
    private javax.swing.JTextField txt_nombre;
    private javax.swing.JButton visa;
    // End of variables declaration//GEN-END:variables
}

